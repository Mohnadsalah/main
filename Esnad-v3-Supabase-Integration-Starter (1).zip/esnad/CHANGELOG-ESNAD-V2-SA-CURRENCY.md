# Esnad V2 — Saudi currency & profile naming update

- Updated monetary display from Jordanian dinar notation to Saudi Riyal (`ر.س`).
- Updated the primary demo beneficiary name to `موضي إبراهيم`.
- Updated relevant name-field placeholders to `موضي إبراهيم`.
- Updated demo phone placeholders/contact samples from Jordanian `+962` format to Saudi `+966` format.
- Remaining illustrative person names are intentionally preserved for review before replacement.
