-- Esnad production database starter (PostgreSQL / Supabase)
-- Do not expose beneficiary PII through anonymous client policies.
create extension if not exists pgcrypto;

create type public.aid_request_status as enum ('pending', 'under_review', 'approved', 'rejected', 'completed');

create table if not exists public.beneficiary_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text not null,
  region text not null,
  address text not null,
  marital_status text not null,
  family_size integer not null check (family_size between 1 and 20),
  has_income boolean not null default false,
  monthly_income numeric(12,2) check (monthly_income is null or monthly_income >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.aid_requests (
  id uuid primary key default gen_random_uuid(),
  reference_code text not null unique default ('ESN-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 10))),
  beneficiary_id uuid not null references public.beneficiary_profiles(id) on delete cascade,
  programs text[] not null check (cardinality(programs) > 0),
  urgent boolean not null default false,
  status public.aid_request_status not null default 'pending',
  beneficiary_notes text,
  review_notes text,
  submitted_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.aid_request_documents (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.aid_requests(id) on delete cascade,
  document_type text not null check (document_type in ('national_id', 'family_document', 'address_proof', 'medical_document')),
  storage_path text,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  unique (request_id, document_type)
);

create index if not exists aid_requests_beneficiary_submitted_idx
  on public.aid_requests (beneficiary_id, submitted_at desc);
create index if not exists aid_requests_status_submitted_idx
  on public.aid_requests (status, submitted_at desc);

alter table public.beneficiary_profiles enable row level security;
alter table public.aid_requests enable row level security;
alter table public.aid_request_documents enable row level security;

-- Beneficiaries can only read/update their own profile and read their own requests.
create policy "beneficiaries read own profile" on public.beneficiary_profiles
  for select to authenticated using (id = auth.uid());
create policy "beneficiaries create own profile" on public.beneficiary_profiles
  for insert to authenticated with check (id = auth.uid());
create policy "beneficiaries update own profile" on public.beneficiary_profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "beneficiaries read own requests" on public.aid_requests
  for select to authenticated using (beneficiary_id = auth.uid());
create policy "beneficiaries create own requests" on public.aid_requests
  for insert to authenticated with check (beneficiary_id = auth.uid());
create policy "beneficiaries read own request documents" on public.aid_request_documents
  for select to authenticated using (
    exists (select 1 from public.aid_requests r where r.id = request_id and r.beneficiary_id = auth.uid())
  );

-- No anonymous policies are intentionally defined. Staff review/status changes should be
-- performed through a server-side trusted role or carefully scoped staff role policies.
