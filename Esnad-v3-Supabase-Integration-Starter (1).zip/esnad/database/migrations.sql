-- Esnad security hardening migration for Supabase/PostgreSQL.
-- Run after database/schema.sql in the Supabase SQL Editor.
-- No public/anon access is granted to beneficiary PII.

create table if not exists public.staff_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('reviewer', 'admin')),
  created_at timestamptz not null default now()
);

alter table public.staff_members enable row level security;

-- SECURITY DEFINER avoids RLS recursion while checking the staff membership table.
create or replace function public.is_esnad_staff()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.staff_members sm
    where sm.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_esnad_staff() from public;
grant execute on function public.is_esnad_staff() to authenticated;

-- A signed-in staff member may see their own role only. Membership is provisioned
-- by a trusted administrator through the Supabase dashboard/server, never the client.
drop policy if exists "staff read own membership" on public.staff_members;
create policy "staff read own membership"
  on public.staff_members for select to authenticated
  using (user_id = (select auth.uid()));

-- Staff can review requests. Beneficiaries retain access only to their own records.
drop policy if exists "staff read requests" on public.aid_requests;
create policy "staff read requests"
  on public.aid_requests for select to authenticated
  using (public.is_esnad_staff());

drop policy if exists "staff update requests" on public.aid_requests;
create policy "staff update requests"
  on public.aid_requests for update to authenticated
  using (public.is_esnad_staff())
  with check (public.is_esnad_staff());

drop policy if exists "staff read profiles" on public.beneficiary_profiles;
create policy "staff read profiles"
  on public.beneficiary_profiles for select to authenticated
  using (public.is_esnad_staff());

drop policy if exists "staff read request documents" on public.aid_request_documents;
create policy "staff read request documents"
  on public.aid_request_documents for select to authenticated
  using (public.is_esnad_staff());

-- updated_at helper for tables which have that column.
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_beneficiary_profiles_updated_at on public.beneficiary_profiles;
create trigger set_beneficiary_profiles_updated_at
  before update on public.beneficiary_profiles
  for each row execute function public.set_updated_at();

drop trigger if exists set_aid_requests_updated_at on public.aid_requests;
create trigger set_aid_requests_updated_at
  before update on public.aid_requests
  for each row execute function public.set_updated_at();

-- Intentionally do not add anonymous policies or expose the service_role key.
