import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import {
  Search,
  Filter,
  Plus,
  Eye,
  X,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { DashboardShell } from '../components/DashboardShell';
import { getMyRequests, getStoredRequests, type StoredRequest } from '../services';
import { isSupabaseConfigured } from '../supabase';

/* ─────────────────────────── Types ─────────────────────────── */
type Status = 'approved' | 'pending' | 'completed' | 'rejected';
interface Request {
  id: string;
  type: string;
  date: string;
  status: Status;
  priority: 'عالية' | 'متوسطة' | 'منخفضة';
  notes: string;
}

/* ─────────────────────────── Mock Data ─────────────────────── */
const REQUESTS: Request[] = [
  { id: 'REQ-2026-001', type: 'مساعدة غذائية',  date: '10 أبريل 2026',  status: 'approved',  priority: 'عالية',   notes: 'تم الموافقة وجاري التوصيل' },
  { id: 'REQ-2026-002', type: 'مساعدة طبية',    date: '05 أبريل 2026',  status: 'pending',   priority: 'عالية',   notes: 'قيد المراجعة من فريق الصحة' },
  { id: 'REQ-2026-003', type: 'دعم تعليمي',     date: '28 مارس 2026',   status: 'completed', priority: 'متوسطة',  notes: 'تم صرف الدعم المدرسي' },
  { id: 'REQ-2026-004', type: 'مساعدة إيواء',   date: '15 مارس 2026',   status: 'rejected',  priority: 'متوسطة',  notes: 'يرجى إعادة تقديم المستندات' },
  { id: 'REQ-2026-005', type: 'مساعدة غذائية',  date: '01 مارس 2026',   status: 'completed', priority: 'منخفضة', notes: 'اكتملت عملية الصرف بنجاح' },
  { id: 'REQ-2026-006', type: 'دعم نفسي',       date: '20 فبراير 2026', status: 'approved',  priority: 'متوسطة',  notes: 'تم تحديد موعد الجلسة' },
  { id: 'REQ-2026-007', type: 'مساعدة مالية',   date: '10 فبراير 2026', status: 'pending',   priority: 'عالية',   notes: 'في انتظار التحقق من الوثائق' },
  { id: 'REQ-2026-008', type: 'كسوة شتوية',     date: '28 يناير 2026',  status: 'completed', priority: 'منخفضة', notes: 'تم التسليم في مركز التوزيع' },
];

/* ─────────────────────────── Config ────────────────────────── */
const STATUS_CONFIG: Record<Status, { label: string; bg: string; text: string; dot: string }> = {
  approved:  { label: 'موافق عليه',    bg: 'bg-emerald-50',  text: 'text-emerald-700', dot: 'bg-emerald-500' },
  pending:   { label: 'قيد المراجعة', bg: 'bg-blue-50',     text: 'text-blue-700',    dot: 'bg-blue-500'    },
  completed: { label: 'مكتمل',        bg: 'bg-[#e8f5ef]',   text: 'text-[#2D6A4F]',  dot: 'bg-[#2D6A4F]'  },
  rejected:  { label: 'مرفوض',        bg: 'bg-red-50',      text: 'text-red-700',     dot: 'bg-red-500'     },
};
const PRIORITY_CONFIG = {
  عالية:    'bg-red-50 text-red-600',
  متوسطة:  'bg-amber-50 text-amber-700',
  منخفضة:  'bg-gray-100 text-gray-600',
};

function StatusBadge({ status }: { status: Status }) {
  const c = STATUS_CONFIG[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs ${c.bg} ${c.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
      {c.label}
    </span>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function RequestsPage() {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<Status | 'all'>('all');
  const [viewReq, setViewReq] = useState<Request | null>(null);
  const [storedRequests, setStoredRequests] = useState<StoredRequest[]>(() => getStoredRequests());
  useEffect(() => {
    let active = true;
    const refresh = () => { getMyRequests().then(rows => { if (active) setStoredRequests(rows); }).catch(() => { if (active) setStoredRequests(getStoredRequests()); }); };
    refresh();
    window.addEventListener('esnad:requests-updated', refresh);
    window.addEventListener('storage', refresh);
    return () => { active = false; window.removeEventListener('esnad:requests-updated', refresh); window.removeEventListener('storage', refresh); };
  }, []);
  const allRequests: Request[] = [
    ...storedRequests.map(r => ({ id: r.id, type: r.type, date: r.date, status: r.status, priority: r.priority, notes: r.notes })),
    ...(isSupabaseConfigured ? [] : REQUESTS),
  ];

  const filtered = allRequests.filter(r => {
    const matchSearch = r.id.toLowerCase().includes(search.toLowerCase()) || r.type.includes(search);
    const matchStatus = filterStatus === 'all' || r.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const counts = {
    active:    allRequests.filter(r => r.status === 'pending' || r.status === 'approved').length,
    completed: allRequests.filter(r => r.status === 'completed').length,
    pending:   allRequests.filter(r => r.status === 'pending').length,
    rejected:  allRequests.filter(r => r.status === 'rejected').length,
  };

  return (
    <DashboardShell>
      {/* Header */}
      <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-[#212529]">طلباتي</h2>
          <p className="text-gray-400 text-sm mt-0.5">سجل جميع طلبات المساعدة المقدّمة ومتابعة حالتها</p>
        </div>
        <Link to="/request"
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors text-sm shadow-sm whitespace-nowrap">
          <Plus size={16} />
          طلب جديد
        </Link>
      </motion.div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'إجمالي الطلبات', value: REQUESTS.length, icon: Clock,        bg: 'bg-white',         text: 'text-[#212529]', sub: 'text-gray-400' },
          { label: 'نشطة ومعتمدة',  value: counts.active,   icon: TrendingUp,   bg: 'bg-[#2D6A4F]',    text: 'text-white',     sub: 'text-white/60' },
          { label: 'مكتملة',         value: counts.completed, icon: CheckCircle,  bg: 'bg-[#A9D6E5]',    text: 'text-[#1a6b8a]', sub: 'text-[#1a6b8a]/60' },
          { label: 'مرفوضة',         value: counts.rejected,  icon: AlertCircle,  bg: 'bg-white',         text: 'text-red-600',   sub: 'text-gray-400' },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <motion.div key={card.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
              className={`${card.bg} rounded-2xl p-4 border border-gray-100 shadow-sm`}>
              <div className="flex items-start justify-between mb-2">
                <div className={`w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center`}>
                  <Icon size={16} className={card.text} />
                </div>
              </div>
              <p className={`text-2xl ${card.text}`}>{card.value}</p>
              <p className={`text-xs mt-0.5 ${card.sub}`}>{card.label}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Table Card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}
        className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Toolbar */}
        <div className="px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-[#212529] text-sm">سجل الطلبات</h3>
            <p className="text-gray-400 text-xs mt-0.5">{allRequests.length} طلب إجمالاً</p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative">
              <Search size={14} className="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400" />
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث..."
                className="pr-9 pl-4 py-2 rounded-lg border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] w-40" />
            </div>
            <div className="relative">
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as Status | 'all')}
                className="appearance-none pr-3 pl-8 py-2 rounded-lg border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] cursor-pointer">
                <option value="all">الكل</option>
                <option value="approved">موافق عليه</option>
                <option value="pending">قيد المراجعة</option>
                <option value="completed">مكتمل</option>
                <option value="rejected">مرفوض</option>
              </select>
              <Filter size={12} className="absolute top-1/2 -translate-y-1/2 left-3 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 text-gray-400 text-xs">
                <th className="px-6 py-3 text-right">رقم الطلب</th>
                <th className="px-6 py-3 text-right">نوع المساعدة</th>
                <th className="px-6 py-3 text-right">الأولوية</th>
                <th className="px-6 py-3 text-right">تاريخ التقديم</th>
                <th className="px-6 py-3 text-right">الحالة</th>
                <th className="px-6 py-3 text-right">ملاحظات</th>
                <th className="px-6 py-3 text-center">عرض</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-300">
                    <AlertCircle size={28} className="mx-auto mb-2 opacity-30" />
                    <p className="text-sm">لا توجد طلبات مطابقة</p>
                  </td>
                </tr>
              ) : filtered.map((req, i) => (
                <motion.tr key={req.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}
                  className="hover:bg-gray-50/80 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="font-mono text-xs text-[#2D6A4F] bg-[#e8f5ef] px-2 py-1 rounded">{req.id}</span>
                  </td>
                  <td className="px-6 py-4 text-[#212529] text-sm">{req.type}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex px-2.5 py-0.5 rounded-md text-xs ${PRIORITY_CONFIG[req.priority]}`}>{req.priority}</span>
                  </td>
                  <td className="px-6 py-4 text-gray-400 text-xs">
                    <span className="flex items-center gap-1.5"><Calendar size={11} />{req.date}</span>
                  </td>
                  <td className="px-6 py-4"><StatusBadge status={req.status} /></td>
                  <td className="px-6 py-4 text-gray-400 text-xs max-w-[180px] truncate" title={req.notes}>{req.notes}</td>
                  <td className="px-6 py-4 text-center">
                    <button onClick={() => setViewReq(req)}
                      className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-[#2D6A4F] hover:text-white text-gray-500 flex items-center justify-center mx-auto transition-colors">
                      <Eye size={14} />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-gray-100 flex items-center justify-between text-xs text-gray-400">
          <span>عرض {filtered.length} من {allRequests.length} طلب</span>
          <Link to="/request" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors text-xs">
            <Plus size={12} />
            طلب جديد
          </Link>
        </div>
      </motion.div>

      {/* Detail Modal */}
      <AnimatePresence>
        {viewReq && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={e => e.target === e.currentTarget && setViewReq(null)}>
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden" dir="rtl">
              <div className="bg-[#2D6A4F] px-6 py-5 flex items-center justify-between">
                <h3 className="text-white">تفاصيل الطلب</h3>
                <button onClick={() => setViewReq(null)} className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white">
                  <X size={16} />
                </button>
              </div>
              <div className="p-6 space-y-4">
                {[
                  { label: 'رقم الطلب',      value: viewReq.id },
                  { label: 'نوع المساعدة',   value: viewReq.type },
                  { label: 'تاريخ التقديم',  value: viewReq.date },
                  { label: 'الأولوية',        value: viewReq.priority },
                  { label: 'ملاحظات',         value: viewReq.notes },
                ].map(({ label, value }) => (
                  <div key={label} className="flex justify-between items-start">
                    <span className="text-gray-400 text-sm">{label}</span>
                    <span className="text-[#212529] text-sm max-w-[55%] text-right">{value}</span>
                  </div>
                ))}
                <div className="flex justify-between items-center pt-1">
                  <span className="text-gray-400 text-sm">الحالة</span>
                  <StatusBadge status={viewReq.status} />
                </div>
              </div>
              <div className="px-6 pb-6 flex gap-3">
                {viewReq.status === 'rejected' && (
                  <Link to="/request" onClick={() => setViewReq(null)}
                    className="flex-1 py-2.5 rounded-xl bg-[#FFB703] text-[#212529] text-center text-sm hover:bg-[#e6a500] transition-colors">
                    إعادة التقديم
                  </Link>
                )}
                <button onClick={() => setViewReq(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors text-sm">
                  إغلاق
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </DashboardShell>
  );
}
