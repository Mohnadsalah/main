import { motion } from 'motion/react';
import { Link } from 'react-router';
import {
  Heart,
  Shield,
  Users,
  Globe,
  Target,
  Sparkles,
  ArrowLeft,
  CheckCircle,
  BookOpen,
  HandHeart,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';

/* ─────────────────────────── Data ──────────────────────────── */
const VALUES = [
  {
    icon: Heart,
    title: 'الإنسانية',
    desc: 'نضع الكرامة الإنسانية في قلب كل قرار نتخذه، ونسعى لتقديم المساعدة بأسلوب يحفظ كرامة المستفيدين.',
    color: 'bg-rose-50 text-rose-600',
    border: 'border-rose-100',
  },
  {
    icon: Shield,
    title: 'الشفافية',
    desc: 'نلتزم بأعلى معايير الشفافية في إدارة الموارد وتوثيق كل عملية مساعدة حتى آخر درهم.',
    color: 'bg-[#e8f5ef] text-[#2D6A4F]',
    border: 'border-[#c5e8d8]',
  },
  {
    icon: Users,
    title: 'الشراكة',
    desc: 'نبني شراكات حقيقية مع الجهات الحكومية والمنظمات الدولية والمجتمعات المحلية لتضخيم الأثر.',
    color: 'bg-[#e8f3f9] text-[#1a6b8a]',
    border: 'border-[#b8d9eb]',
  },
  {
    icon: Globe,
    title: 'الاستدامة',
    desc: 'نصمم برامجنا لتترك أثراً دائماً، لا مساعدة آنية فحسب، بل بناء قدرات تضمن كرامة المستفيد مستقبلاً.',
    color: 'bg-amber-50 text-amber-600',
    border: 'border-amber-100',
  },
];

const STATS = [
  { value: '142,000+', label: 'مستفيد مسجّل', sub: 'في 8 محافظات' },
  { value: '38M+',     label: 'ريال مُنفق', sub: 'خلال 4 سنوات'  },
  { value: '97%',      label: 'رضا المستفيدين', sub: 'وفق آخر مسح'  },
  { value: '220+',     label: 'شريك مؤسسي',    sub: 'حكومي وأهلي'  },
];

const TIMELINE = [
  { year: '2020', title: 'التأسيس', desc: 'أُطلقت منصة إسناد استجابةً لأزمة كوفيد-19 بتغطية 12,000 أسرة في الشهر الأول.' },
  { year: '2021', title: 'التوسع', desc: 'تمددت العمليات لتشمل 8 محافظات وأُضيفت برامج الدعم النفسي والتعليمي.' },
  { year: '2023', title: 'الرقمنة', desc: 'إطلاق لوحة التحكم الرقمية ليتمكن المستفيدون من متابعة طلباتهم أونلاين.' },
  { year: '2026', title: 'اليوم', desc: 'أكثر من 142,000 مستفيد وشراكات مع 220 جهة محلية ودولية.' },
];

const TEAM = [
  {
    name: 'غدي راشد القينان',
    serial: '444929000',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'غ',
    bg: 'bg-[#2D6A4F]',
  },
  {
    name: 'شهد ابراهيم المرشد',
    serial: '444928964',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'ش',
    bg: 'bg-[#1a6b8a]',
  },
  {
    name: 'اميره عصام عبده محمد',
    serial: '445926240',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'أ',
    bg: 'bg-[#7a5400]',
  },
  {
    name: 'شذى مناحي القحطاني',
    serial: '445926254',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'ش',
    bg: 'bg-[#2D6A4F]',
  },
  {
    name: 'موضي ابراهيم ابوذيب',
    serial: '445926242',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'م',
    bg: 'bg-[#1a6b8a]',
  },
  {
    name: 'هنادي احمد عبد الخالق',
    serial: '445926160',
    role: 'عضو فريق إسناد',
    bio: 'ضمن الفريق الذي يعمل على تطوير تجربة إنسانية أكثر سهولة وشفافية.',
    initials: 'هـ',
    bg: 'bg-[#7a5400]',
  },
];

/* ─────────────────────────── Components ────────────────────── */

function HeroAbout() {
  return (
    <section className="relative min-h-[70vh] flex items-center pt-20 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#2D6A4F] via-[#1f4a37] to-[#1a3d2e]" />
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full bg-[#FFB703] blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-80 h-80 rounded-full bg-[#A9D6E5] blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 w-full">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 mb-6"
          >
            <Sparkles size={14} className="text-[#FFB703]" />
            <span className="text-white/80 text-sm">من نحن</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl lg:text-6xl text-white mb-6 leading-tight"
          >
            نسند الإنسان
            <span className="block text-[#FFB703]">في أصعب لحظاته</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-white/70 text-lg leading-relaxed mb-8 max-w-2xl"
          >
            إسناد منصة إنسانية رقمية تربط المستفيدين بالموارد والمساعدات بشكل مباشر وشفاف، تأسست عام 2020 استجابةً لأزمة كوفيد، ولا تزال تكبر لأن الحاجة لا تتوقف.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-4"
          >
            <Link
              to="/request"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors shadow-lg font-medium"
            >
              ابدأ الآن
              <ArrowLeft size={18} />
            </Link>
            <a
              href="#team"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
            >
              تعرّف على فريقنا
            </a>
          </motion.div>
        </div>

        {/* Floating cards */}
        <motion.div
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="absolute left-8 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-4"
        >
          {[
            { icon: CheckCircle, label: 'موثوق ومعتمد', color: 'text-emerald-400' },
            { icon: HandHeart,   label: 'إنساني بالكامل', color: 'text-rose-300' },
            { icon: BookOpen,    label: 'شفاف ومحاسَب',  color: 'text-[#A9D6E5]' },
          ].map(({ icon: Icon, label, color }) => (
            <div key={label} className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/10 border border-white/15 backdrop-blur-sm">
              <Icon size={18} className={color} />
              <span className="text-white text-sm">{label}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 60L1440 60L1440 20C1200 60 960 0 720 20C480 40 240 0 0 20L0 60Z" fill="#F8F9FA" />
        </svg>
      </div>
    </section>
  );
}

function ImpactStats() {
  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {STATS.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="text-center p-6 rounded-2xl bg-[#F8F9FA] hover:shadow-md transition-shadow"
            >
              <p className="text-3xl lg:text-4xl text-[#2D6A4F] mb-1">{stat.value}</p>
              <p className="text-[#212529] mb-1">{stat.label}</p>
              <p className="text-gray-400 text-xs">{stat.sub}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function MissionSection() {
  return (
    <section className="py-20 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#e8f5ef] mb-6">
              <Target size={14} className="text-[#2D6A4F]" />
              <span className="text-[#2D6A4F] text-sm">رسالتنا ورؤيتنا</span>
            </div>
            <h2 className="text-3xl lg:text-4xl text-[#212529] mb-6 leading-tight">
              مساعدة أسرع،
              <span className="text-[#2D6A4F] block">وأثر أعمق</span>
            </h2>
            <p className="text-gray-500 leading-relaxed mb-6 text-lg">
              رسالتنا هي ضمان وصول المساعدة الإنسانية إلى كل من يحتاجها في أسرع وقت وبأعلى شفافية، مع صون كرامة المستفيد في كل خطوة.
            </p>
            <p className="text-gray-500 leading-relaxed mb-8">
              ورؤيتنا هي مجتمع خالٍ من الحرمان، تُدار فيه الموارد الإنسانية بكفاءة وشفافية عبر منظومة رقمية متكاملة تربط الجميع.
            </p>
            <div className="flex flex-col gap-3">
              {[
                'التسجيل والتحقق الرقمي السريع',
                'تتبع الطلبات في الوقت الفعلي',
                'تقارير أثر مفصّلة للشركاء',
                'دعم متعدد القنوات للمستفيدين',
              ].map(item => (
                <div key={item} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-[#e8f5ef] flex items-center justify-center flex-shrink-0">
                    <CheckCircle size={12} className="text-[#2D6A4F]" />
                  </div>
                  <span className="text-gray-600 text-sm">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="relative"
          >
            <div className="relative bg-gradient-to-br from-[#2D6A4F] to-[#1f4a37] rounded-3xl p-8 text-white overflow-hidden">
              <div className="absolute top-0 left-0 w-40 h-40 rounded-full bg-white/5 -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 right-0 w-32 h-32 rounded-full bg-[#FFB703]/10 translate-x-1/3 translate-y-1/3" />
              <div className="relative space-y-6">
                <div className="w-14 h-14 rounded-2xl bg-[#FFB703] flex items-center justify-center">
                  <HandHeart size={26} className="text-[#212529]" />
                </div>
                <h3 className="text-2xl">برامج المساعدة</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    'مساعدة غذائية', 'رعاية طبية',
                    'دعم تعليمي',   'إيواء طارئ',
                    'دعم نفسي',     'مساعدة مالية',
                  ].map(prog => (
                    <div key={prog} className="bg-white/10 rounded-xl px-3 py-2 text-sm text-white/90">
                      {prog}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ValuesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#e8f5ef] mb-4">
            <Sparkles size={14} className="text-[#2D6A4F]" />
            <span className="text-[#2D6A4F] text-sm">قيمنا الأساسية</span>
          </div>
          <h2 className="text-3xl lg:text-4xl text-[#212529] mb-4">ما يقودنا كل يوم</h2>
          <p className="text-gray-500 max-w-xl mx-auto">
            هذه القيم ليست شعارات على الجدران، بل معايير نقيس بها كل قرار وكل إجراء داخل المنصة.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {VALUES.map((val, i) => (
            <motion.div
              key={val.title}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className={`rounded-2xl p-6 border ${val.border} hover:shadow-md transition-shadow group cursor-default`}
            >
              <div className={`w-12 h-12 rounded-xl ${val.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <val.icon size={22} />
              </div>
              <h3 className="text-[#212529] mb-3">{val.title}</h3>
              <p className="text-gray-500 text-sm leading-relaxed">{val.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TimelineSection() {
  return (
    <section className="py-20 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl lg:text-4xl text-[#212529] mb-4">قصة إسناد</h2>
          <p className="text-gray-500 max-w-lg mx-auto">من استجابة طارئة إلى منظومة إنسانية رقمية متكاملة</p>
        </motion.div>

        <div className="relative">
          <div className="absolute right-8 lg:right-1/2 top-0 bottom-0 w-px bg-[#2D6A4F]/20" />
          <div className="space-y-10">
            {TIMELINE.map((item, i) => (
              <motion.div
                key={item.year}
                initial={{ opacity: 0, x: i % 2 === 0 ? 30 : -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className={`flex gap-6 items-start ${i % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} lg:w-1/2 ${i % 2 === 0 ? 'lg:mr-auto' : 'lg:ml-auto'}`}
              >
                <div className="relative flex-shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-[#2D6A4F] text-white flex items-center justify-center text-sm shadow-lg">
                    {item.year}
                  </div>
                </div>
                <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex-1">
                  <h3 className="text-[#212529] mb-2">{item.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TeamSection() {
  return (
    <section id="team" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl lg:text-4xl text-[#212529] mb-4">الفريق القيادي</h2>
          <p className="text-gray-500 max-w-lg mx-auto">محترفون من خلفيات إنسانية وتقنية يؤمنون بأن التكنولوجيا تخدم الإنسان</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {TEAM.map((member, i) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="text-center group"
            >
              <div className={`w-20 h-20 rounded-2xl ${member.bg} flex items-center justify-center text-white text-2xl mx-auto mb-4 shadow-md group-hover:scale-105 transition-transform`}>
                {member.initials}
              </div>
              <h3 className="text-[#212529] mb-1">{member.name}</h3>
              <p className="text-[#2D6A4F] text-sm mb-1">{member.role}</p>
              <p className="text-[#212529]/70 text-xs font-semibold tracking-wide mb-3" dir="ltr">الرقم التسلسلي: {member.serial}</p>
              <p className="text-gray-400 text-xs leading-relaxed">{member.bio}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-br from-[#2D6A4F] to-[#1f4a37] relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-[#FFB703] blur-3xl" />
        <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-[#A9D6E5] blur-3xl" />
      </div>
      <div className="relative max-w-3xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-16 h-16 rounded-2xl bg-[#FFB703] flex items-center justify-center mx-auto mb-6 shadow-xl">
            <HandHeart size={28} className="text-[#212529]" />
          </div>
          <h2 className="text-3xl lg:text-4xl text-white mb-4">هل تحتاج إلى مساعدة؟</h2>
          <p className="text-white/70 text-lg mb-8 leading-relaxed">
            سجّل في منصة إسناد اليوم وابدأ رحلتك نحو الحصول على الدعم الذي تستحقه بكل شفافية وكرامة.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors shadow-lg font-medium"
            >
              سجّل الآن مجاناً
              <ArrowLeft size={18} />
            </Link>
            <a
              href="mailto:support@esnad.jo"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
            >
              تواصل معنا
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ─────────────────────────── Footer strip ──────────────────── */
function FooterStrip() {
  return (
    <footer className="bg-[#212529] py-6">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-400 text-sm">
        <p>© 2026 منصة إسناد — جميع الحقوق محفوظة</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
          <a href="#" className="hover:text-white transition-colors">شروط الاستخدام</a>
          <a href="#" className="hover:text-white transition-colors">تواصل معنا</a>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function AboutPage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />
      <HeroAbout />
      <ImpactStats />
      <MissionSection />
      <ValuesSection />
      <TimelineSection />
      <TeamSection />
      <CTASection />
      <FooterStrip />
    </div>
  );
}
