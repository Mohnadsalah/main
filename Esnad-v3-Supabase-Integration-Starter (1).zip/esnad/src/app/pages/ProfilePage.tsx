import { useState } from 'react';
import { motion } from 'motion/react';
import {
  User,
  Phone,
  MapPin,
  CreditCard,
  Users,
  Edit3,
  Save,
  X,
  Upload,
  CheckCircle,
  Shield,
  Bell,
  Eye,
  EyeOff,
  Camera,
  FileText,
  Trash2,
  Clock,
} from 'lucide-react';
import { DashboardShell } from '../components/DashboardShell';

/* ─────────────────────────── Types ─────────────────────────── */
interface PersonalInfo {
  fullName: string;
  nationalId: string;
  phone: string;
  address: string;
  city: string;
  familySize: string;
  maritalStatus: string;
}

/* ─────────────────────────── Mock Documents ────────────────── */
const DOCS = [
  { id: 1, name: 'بطاقة الهوية الوطنية', status: 'verified', date: '12 يناير 2026', size: '1.2 MB' },
  { id: 2, name: 'وثيقة الوضع الأسري',   status: 'verified', date: '12 يناير 2026', size: '0.8 MB' },
  { id: 3, name: 'إثبات العنوان',         status: 'pending',  date: '05 أبريل 2026', size: '2.1 MB' },
];

const DOC_STATUS: Record<string, { label: string; bg: string; text: string }> = {
  verified: { label: 'موثّق',        bg: 'bg-[#e8f5ef]', text: 'text-[#2D6A4F]' },
  pending:  { label: 'قيد المراجعة', bg: 'bg-amber-50',  text: 'text-amber-700' },
  rejected: { label: 'مرفوض',        bg: 'bg-red-50',    text: 'text-red-600'   },
};

const CITIES = ['الرياض', 'مكة المكرمة', 'المدينة المنورة', 'المنطقة الشرقية', 'عسير', 'تبوك', 'القصيم', 'جازان'];

/* ─────────────────────────── Status Badge ──────────────────── */
function AccountStatusBadge() {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#e8f5ef] border border-[#c5e8d8]">
      <span className="w-2 h-2 rounded-full bg-[#2D6A4F] animate-pulse" />
      <span className="text-[#2D6A4F] text-xs">حساب نشط وموثّق</span>
    </div>
  );
}

/* ─────────────────────────── Avatar Section ────────────────── */
function AvatarCard({ editing }: { editing: boolean }) {
  return (
    <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
      <div className="relative flex-shrink-0">
        <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-[#2D6A4F] to-[#1f4a37] flex items-center justify-center text-white text-3xl shadow-lg">
          أ
        </div>
        {editing && (
          <button className="absolute -bottom-2 -left-2 w-8 h-8 rounded-full bg-[#FFB703] text-[#212529] flex items-center justify-center shadow-md hover:bg-[#e6a500] transition-colors">
            <Camera size={14} />
          </button>
        )}
      </div>
      <div className="text-center sm:text-right">
        <h3 className="text-[#212529] text-xl mb-1">موضي إبراهيم</h3>
        <p className="text-gray-400 text-sm mb-3">مستفيد مسجّل · عضو منذ يناير 2026</p>
        <AccountStatusBadge />
      </div>
    </div>
  );
}

/* ─────────────────────────── Personal Info Form ────────────── */
function PersonalInfoSection() {
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [info, setInfo] = useState<PersonalInfo>({
    fullName:      'موضي إبراهيم',
    nationalId:    '9*******2',
    phone:         '+966 5* *** ****',
    address:       'شارع المدينة المنورة، مبنى 12',
    city:          'الرياض',
    familySize:    '5',
    maritalStatus: 'متزوج',
  });

  const handleSave = () => {
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const fields: { key: keyof PersonalInfo; label: string; icon: typeof User; type?: string; options?: string[] }[] = [
    { key: 'fullName',      label: 'الاسم الكامل',          icon: User       },
    { key: 'nationalId',    label: 'رقم الهوية الوطنية',    icon: CreditCard },
    { key: 'phone',         label: 'رقم الهاتف',            icon: Phone      },
    { key: 'address',       label: 'العنوان التفصيلي',      icon: MapPin     },
    { key: 'city',          label: 'المدينة / المحافظة',    icon: MapPin,    options: CITIES },
    { key: 'familySize',    label: 'عدد أفراد الأسرة',      icon: Users,     type: 'number' },
    { key: 'maritalStatus', label: 'الحالة الاجتماعية',     icon: User,      options: ['أعزب', 'متزوج', 'مطلق', 'أرمل'] },
  ];

  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
        <div>
          <h3 className="text-[#212529]">البيانات الشخصية</h3>
          <p className="text-gray-400 text-xs mt-0.5">المعلومات المرتبطة بحسابك في إسناد</p>
        </div>
        <div className="flex items-center gap-2">
          {saved && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#e8f5ef] text-[#2D6A4F] text-xs"
            >
              <CheckCircle size={12} />
              تم الحفظ
            </motion.div>
          )}
          {editing ? (
            <>
              <button
                onClick={() => setEditing(false)}
                className="w-8 h-8 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50 flex items-center justify-center transition-colors"
              >
                <X size={16} />
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#2D6A4F] text-white hover:bg-[#1f4a37] transition-colors text-sm"
              >
                <Save size={14} />
                حفظ التغييرات
              </button>
            </>
          ) : (
            <button
              onClick={() => setEditing(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#2D6A4F] text-[#2D6A4F] hover:bg-[#e8f5ef] transition-colors text-sm"
            >
              <Edit3 size={14} />
              تعديل
            </button>
          )}
        </div>
      </div>

      {/* Avatar */}
      <div className="px-6 py-5 border-b border-gray-50">
        <AvatarCard editing={editing} />
      </div>

      {/* Fields Grid */}
      <div className="p-6 grid sm:grid-cols-2 gap-5">
        {fields.map(({ key, label, icon: Icon, type, options }) => (
          <div key={key}>
            <label className="flex items-center gap-1.5 text-xs text-gray-500 mb-1.5">
              <Icon size={12} />
              {label}
            </label>
            {editing ? (
              options ? (
                <select
                  value={info[key]}
                  onChange={e => setInfo({ ...info, [key]: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
                >
                  {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              ) : (
                <input
                  type={type ?? 'text'}
                  value={info[key]}
                  onChange={e => setInfo({ ...info, [key]: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
                />
              )
            ) : (
              <p className="text-[#212529] text-sm py-2.5 px-4 rounded-xl bg-gray-50 border border-transparent">
                {key === 'nationalId' || key === 'phone' ? (
                  <span className="font-mono">{info[key]}</span>
                ) : info[key]}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────────────────────── Documents Section ─────────────── */
function DocumentsSection() {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
        <div>
          <h3 className="text-[#212529]">المستندات الرسمية</h3>
          <p className="text-gray-400 text-xs mt-0.5">الوثائق المرفوعة والمرتبطة بحسابك</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors text-sm shadow-sm">
          <Upload size={14} />
          رفع وثيقة
        </button>
      </div>

      <div className="p-4 space-y-3">
        {DOCS.map((doc, i) => {
          const statusCfg = DOC_STATUS[doc.status];
          return (
            <motion.div
              key={doc.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="flex items-center gap-4 p-4 rounded-xl border border-gray-100 hover:border-gray-200 hover:bg-gray-50/50 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#e8f5ef] flex items-center justify-center flex-shrink-0">
                <FileText size={18} className="text-[#2D6A4F]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[#212529] text-sm">{doc.name}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="flex items-center gap-1 text-gray-300 text-xs">
                    <Clock size={10} />
                    {doc.date}
                  </span>
                  <span className="text-gray-300 text-xs">{doc.size}</span>
                </div>
              </div>
              <span className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs ${statusCfg.bg} ${statusCfg.text}`}>
                {statusCfg.label}
              </span>
              <button className="flex-shrink-0 w-8 h-8 rounded-lg text-gray-300 hover:text-red-500 hover:bg-red-50 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100">
                <Trash2 size={14} />
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Upload zone */}
      <div className="mx-4 mb-4">
        <div className="border-2 border-dashed border-gray-200 rounded-xl p-5 flex flex-col items-center gap-2 hover:border-[#2D6A4F] cursor-pointer transition-colors group">
          <Upload size={20} className="text-gray-300 group-hover:text-[#2D6A4F] transition-colors" />
          <p className="text-sm text-gray-400 group-hover:text-[#2D6A4F] transition-colors">اسحب الملف هنا أو انقر للاختيار</p>
          <p className="text-xs text-gray-300">PDF، JPG، PNG — بحد أقصى 5 ميجابايت</p>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────── Settings Section ──────────────── */
function SettingsSection() {
  const [showPass, setShowPass] = useState(false);
  const [notifSettings, setNotifSettings] = useState({
    email: true,
    sms: true,
    push: false,
  });

  return (
    <div className="grid sm:grid-cols-2 gap-5">
      {/* Security */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-[#e8f5ef] flex items-center justify-center">
            <Shield size={16} className="text-[#2D6A4F]" />
          </div>
          <div>
            <h3 className="text-[#212529] text-sm">الأمان وكلمة المرور</h3>
            <p className="text-gray-400 text-xs">آخر تغيير: منذ 3 أشهر</p>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs text-gray-500 mb-1.5 block">كلمة المرور الحالية</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                defaultValue="••••••••"
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] pr-10"
              />
              <button
                onClick={() => setShowPass(s => !s)}
                className="absolute top-1/2 -translate-y-1/2 left-3 text-gray-400 hover:text-[#2D6A4F] transition-colors"
              >
                {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-500 mb-1.5 block">كلمة المرور الجديدة</label>
            <input
              type="password"
              placeholder="كلمة مرور قوية..."
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
            />
          </div>
          <button className="w-full py-2.5 rounded-xl bg-[#2D6A4F] text-white text-sm hover:bg-[#1f4a37] transition-colors">
            تحديث كلمة المرور
          </button>
        </div>
      </div>

      {/* Notifications settings */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center">
            <Bell size={16} className="text-amber-600" />
          </div>
          <div>
            <h3 className="text-[#212529] text-sm">تفضيلات الإشعارات</h3>
            <p className="text-gray-400 text-xs">اختر كيف تصلك التحديثات</p>
          </div>
        </div>
        <div className="space-y-4">
          {[
            { key: 'email' as const, label: 'البريد الإلكتروني', desc: 'تحديثات تفصيلية للطلبات' },
            { key: 'sms'   as const, label: 'رسائل SMS',          desc: 'تنبيهات سريعة لهاتفك'   },
            { key: 'push'  as const, label: 'إشعارات التطبيق',   desc: 'تنبيهات فورية في المنصة' },
          ].map(({ key, label, desc }) => (
            <div key={key} className="flex items-center justify-between py-1">
              <div>
                <p className="text-[#212529] text-sm">{label}</p>
                <p className="text-gray-400 text-xs">{desc}</p>
              </div>
              <button
                onClick={() => setNotifSettings(s => ({ ...s, [key]: !s[key] }))}
                className={`w-11 h-6 rounded-full transition-colors relative flex-shrink-0 ${
                  notifSettings[key] ? 'bg-[#2D6A4F]' : 'bg-gray-200'
                }`}
              >
                <span
                  className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${
                    notifSettings[key] ? 'left-1' : 'right-1'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>
        <div className="mt-5 p-3 rounded-xl bg-[#e8f5ef] border border-[#c5e8d8] flex items-start gap-2">
          <CheckCircle size={14} className="text-[#2D6A4F] mt-0.5 flex-shrink-0" />
          <p className="text-[#2D6A4F] text-xs leading-relaxed">
            سيتم إرسال إشعارات حتى عند تغيير حالة طلباتك العاجلة بصرف النظر عن هذه الإعدادات.
          </p>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function ProfilePage() {
  return (
    <DashboardShell>
      <motion.div
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        className="mb-6"
      >
        <h2 className="text-[#212529]">ملفي الشخصي</h2>
        <p className="text-gray-400 text-sm mt-0.5">إدارة بياناتك الشخصية وإعدادات حسابك</p>
      </motion.div>

      <div className="space-y-5">
        {/* Personal Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <PersonalInfoSection />
        </motion.div>

        {/* Documents */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <DocumentsSection />
        </motion.div>

        {/* Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <SettingsSection />
        </motion.div>

        {/* Danger Zone */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white rounded-2xl border border-red-100 shadow-sm p-5"
        >
          <h3 className="text-red-600 text-sm mb-2 flex items-center gap-2">
            <Shield size={14} />
            منطقة الحذف
          </h3>
          <p className="text-gray-400 text-xs mb-4 leading-relaxed">
            حذف حسابك يزيل جميع بياناتك وطلباتك بشكل نهائي ولا يمكن التراجع عنه.
          </p>
          <button className="px-4 py-2 rounded-xl border border-red-200 text-red-500 hover:bg-red-50 transition-colors text-sm">
            طلب حذف الحساب
          </button>
        </motion.div>
      </div>
    </DashboardShell>
  );
}
