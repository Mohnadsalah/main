import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import {
  Utensils,
  Stethoscope,
  GraduationCap,
  Home,
  Brain,
  Banknote,
  Shirt,
  Wrench,
  ArrowLeft,
  CheckCircle,
  Users,
  ChevronDown,
  Sparkles,
  ClipboardList,
  Clock,
  FileCheck,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';

/* ─────────────────────────── Data ──────────────────────────── */
interface Program {
  id: string;
  icon: typeof Utensils;
  title: string;
  subtitle: string;
  desc: string;
  beneficiaries: string;
  duration: string;
  eligibility: string[];
  color: string;
  bg: string;
  border: string;
  tag: string;
}

const PROGRAMS: Program[] = [
  {
    id: 'food',
    icon: Utensils,
    title: 'المساعدة الغذائية',
    subtitle: 'سلّة غذائية شهرية',
    desc: 'تأمين حزمة غذائية أساسية شهرية تكفي الأسرة لـ 30 يوماً، تشمل الحبوب ومنتجات الألبان والبقوليات والزيوت.',
    beneficiaries: '48,000+',
    duration: '3 أشهر قابلة للتجديد',
    eligibility: ['الأسر متعددة الأفراد (4+)', 'الأرامل ومعيلات الأسر', 'ذوو الدخل المحدود', 'اللاجئون المسجّلون'],
    color: 'text-orange-600',
    bg: 'bg-orange-50',
    border: 'border-orange-100',
    tag: 'الأعلى طلباً',
  },
  {
    id: 'medical',
    icon: Stethoscope,
    title: 'الرعاية الطبية',
    subtitle: 'علاج وأدوية ودعم صحي',
    desc: 'تغطية تكاليف العلاج والأدوية والفحوصات الطبية، مع إمكانية الإحالة إلى المستشفيات الشريكة.',
    beneficiaries: '22,000+',
    duration: 'حسب الحالة الطبية',
    eligibility: ['الحالات الطارئة والمزمنة', 'الأطفال دون 12 سنة', 'كبار السن +65', 'ذوو الإعاقة'],
    color: 'text-rose-600',
    bg: 'bg-rose-50',
    border: 'border-rose-100',
    tag: 'عاجل',
  },
  {
    id: 'education',
    icon: GraduationCap,
    title: 'الدعم التعليمي',
    subtitle: 'قرطاسية وكتب ورسوم مدرسية',
    desc: 'ضمان استمرار الأطفال في التعليم عبر تغطية الرسوم والمستلزمات المدرسية ودعم أنشطة التعلم الإضافية.',
    beneficiaries: '31,000+',
    duration: 'طوال العام الدراسي',
    eligibility: ['الأطفال من 6 إلى 18 سنة', 'المسجّلون في مدارس معتمدة', 'الأسر تحت خط الفقر'],
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-100',
    tag: 'موسمي',
  },
  {
    id: 'housing',
    icon: Home,
    title: 'مساعدة الإيواء',
    subtitle: 'دعم الإيجار والإصلاح',
    desc: 'مساعدة الأسر على تأمين مسكن آمن عبر دعم الإيجار جزئياً أو صيانة الوحدات السكنية المتدهورة.',
    beneficiaries: '14,000+',
    duration: 'حتى 6 أشهر',
    eligibility: ['المشردون حديثاً', 'ضحايا الكوارث', 'الأسر المقيمة في مساكن غير لائقة'],
    color: 'text-[#2D6A4F]',
    bg: 'bg-[#e8f5ef]',
    border: 'border-[#c5e8d8]',
    tag: 'مستمر',
  },
  {
    id: 'mental',
    icon: Brain,
    title: 'الدعم النفسي',
    subtitle: 'جلسات إرشاد ودعم نفسي',
    desc: 'جلسات فردية وجماعية مع مختصين نفسيين معتمدين، تستهدف علاج الصدمات والاضطرابات الناجمة عن الأزمات.',
    beneficiaries: '9,500+',
    duration: '8 جلسات كحد أدنى',
    eligibility: ['ضحايا الصدمات والأزمات', 'الأطفال المتضررون', 'المراهقون والشباب', 'مقدّمو الرعاية'],
    color: 'text-purple-600',
    bg: 'bg-purple-50',
    border: 'border-purple-100',
    tag: 'تخصصي',
  },
  {
    id: 'financial',
    icon: Banknote,
    title: 'المساعدة المالية',
    subtitle: 'تحويل نقدي مباشر',
    desc: 'تحويل مبالغ مالية مباشرة للأسر المحتاجة لتغطية احتياجاتها الأساسية الطارئة وفق معايير محددة.',
    beneficiaries: '18,000+',
    duration: 'مرة إلى 3 مرات سنوياً',
    eligibility: ['الأسر في أزمات طارئة', 'فاقدو العمل حديثاً', 'الأرامل والمطلقات برفقة أطفال'],
    color: 'text-amber-600',
    bg: 'bg-amber-50',
    border: 'border-amber-100',
    tag: 'طارئ',
  },
  {
    id: 'clothing',
    icon: Shirt,
    title: 'الكسوة الموسمية',
    subtitle: 'ملابس شتوية وصيفية',
    desc: 'توفير حزم ملابس موسمية للأطفال والبالغين، مع التركيز على الكسوة الشتوية للأسر الأشد هشاشة.',
    beneficiaries: '27,000+',
    duration: 'موسم واحد سنوياً',
    eligibility: ['الأطفال دون 15 سنة', 'الأسر ذات الدخل المنعدم', 'المسجّلون في قواعد البيانات'],
    color: 'text-cyan-600',
    bg: 'bg-cyan-50',
    border: 'border-cyan-100',
    tag: 'موسمي',
  },
  {
    id: 'equipment',
    icon: Wrench,
    title: 'المعدات المنزلية',
    subtitle: 'أثاث وأجهزة أساسية',
    desc: 'توفير الأثاث الأساسي والأجهزة الكهربائية الضرورية للأسر المفتقرة إليها خاصةً المنشأة حديثاً.',
    beneficiaries: '6,200+',
    duration: 'مرة واحدة',
    eligibility: ['حديثو الزواج تحت خط الفقر', 'الأسر المعاد توطينها', 'ضحايا الكوارث والحرائق'],
    color: 'text-gray-600',
    bg: 'bg-gray-100',
    border: 'border-gray-200',
    tag: 'مرة واحدة',
  },
];

const STEPS = [
  { icon: ClipboardList, title: 'سجّل في المنصة', desc: 'أنشئ حسابك وأكمل بياناتك الشخصية وبيانات الأسرة.' },
  { icon: FileCheck,     title: 'ارفع المستندات',  desc: 'أرفق المستندات المطلوبة (الهوية الوطنية، وثيقة الأسرة، إثبات العنوان).' },
  { icon: Clock,         title: 'انتظر المراجعة',  desc: 'يراجع فريقنا طلبك خلال 3-5 أيام عمل ويتواصل معك.' },
  { icon: CheckCircle,   title: 'استلم المساعدة',  desc: 'تُصرف المساعدة مباشرة أو عبر نقاط التوزيع المعتمدة.' },
];

const TAG_COLORS: Record<string, string> = {
  'الأعلى طلباً': 'bg-orange-100 text-orange-700',
  'عاجل':         'bg-red-100 text-red-600',
  'موسمي':        'bg-blue-100 text-blue-700',
  'مستمر':        'bg-[#e8f5ef] text-[#2D6A4F]',
  'تخصصي':       'bg-purple-100 text-purple-700',
  'طارئ':         'bg-amber-100 text-amber-700',
  'مرة واحدة':   'bg-gray-100 text-gray-600',
};

/* ─────────────────────────── Program Card ──────────────────── */
function ProgramCard({ program, index }: { program: Program; index: number }) {
  const [expanded, setExpanded] = useState(false);
  const Icon = program.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.07, duration: 0.45 }}
      className={`bg-white rounded-2xl border ${program.border} shadow-sm hover:shadow-md transition-all overflow-hidden group`}
    >
      {/* Top */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className={`w-12 h-12 rounded-xl ${program.bg} flex items-center justify-center group-hover:scale-110 transition-transform`}>
            <Icon size={22} className={program.color} />
          </div>
          <span className={`text-xs px-2.5 py-1 rounded-full ${TAG_COLORS[program.tag] ?? 'bg-gray-100 text-gray-600'}`}>
            {program.tag}
          </span>
        </div>

        <h3 className="text-[#212529] mb-0.5">{program.title}</h3>
        <p className={`text-xs mb-3 ${program.color}`}>{program.subtitle}</p>
        <p className="text-gray-500 text-sm leading-relaxed">{program.desc}</p>

        <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100">
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Users size={12} />
            {program.beneficiaries} مستفيد
          </div>
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Clock size={12} />
            {program.duration}
          </div>
        </div>
      </div>

      {/* Expandable eligibility */}
      <div className="border-t border-gray-100">
        <button
          onClick={() => setExpanded(e => !e)}
          className="w-full flex items-center justify-between px-6 py-3 text-sm text-gray-500 hover:bg-gray-50 transition-colors"
        >
          <span>شروط الاستحقاق</span>
          <ChevronDown
            size={16}
            className={`transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`}
          />
        </button>
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="px-6 pb-5 space-y-2">
                {program.eligibility.map(cond => (
                  <div key={cond} className="flex items-start gap-2">
                    <CheckCircle size={13} className={`${program.color} mt-0.5 flex-shrink-0`} />
                    <span className="text-gray-500 text-xs leading-relaxed">{cond}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* CTA */}
      <div className={`px-6 py-4 ${program.bg} flex items-center justify-between`}>
        <Link
          to="/request"
          className={`flex items-center gap-2 text-sm ${program.color} hover:opacity-80 transition-opacity`}
        >
          قدّم طلبك الآن
          <ArrowLeft size={14} />
        </Link>
        <Link to="/programs" className="text-xs text-gray-400 hover:text-gray-600 transition-colors">
          اعرف أكثر
        </Link>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Sections ──────────────────────── */
function HeroPrograms() {
  return (
    <section className="relative min-h-[50vh] flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-[#1f4a37] via-[#2D6A4F] to-[#3a8a65]" />
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/3 right-1/3 w-80 h-80 rounded-full bg-[#FFB703] blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-60 h-60 rounded-full bg-[#A9D6E5] blur-3xl" />
      </div>
      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 w-full py-16">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 mb-6"
        >
          <Sparkles size={14} className="text-[#FFB703]" />
          <span className="text-white/80 text-sm">برامج إسناد</span>
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="text-4xl lg:text-5xl text-white mb-4 leading-tight"
        >
          8 برامج مساعدة
          <span className="block text-[#FFB703]">تلبّي كل احتياج</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-white/70 text-lg max-w-2xl leading-relaxed"
        >
          منصة إسناد تُدير منظومة متكاملة من برامج الدعم الإنساني، صُمّمت بدقة لتغطية أشد الاحتياجات إلحاحاً — من الغذاء إلى الصحة النفسية.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="flex flex-wrap gap-4 mt-8"
        >
          {[
            { val: '8', lbl: 'برامج نشطة' },
            { val: '142K+', lbl: 'مستفيد' },
            { val: '97%', lbl: 'نسبة الرضا' },
          ].map(({ val, lbl }) => (
            <div key={lbl} className="px-5 py-3 rounded-2xl bg-white/10 border border-white/15 text-center">
              <p className="text-2xl text-white">{val}</p>
              <p className="text-white/60 text-xs">{lbl}</p>
            </div>
          ))}
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 50" fill="none"><path d="M0 50L1440 50L1440 15C1200 50 960 0 720 15C480 30 240 0 0 15Z" fill="#F8F9FA" /></svg>
      </div>
    </section>
  );
}

function ProgramsGrid() {
  return (
    <section className="py-16 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl text-[#212529] mb-3">تصفّح برامجنا</h2>
          <p className="text-gray-500">انقر على البرنامج لرؤية شروط الاستحقاق</p>
        </motion.div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {PROGRAMS.map((prog, i) => (
            <ProgramCard key={prog.id} program={prog} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function HowToApply() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl text-[#212529] mb-3">كيف تتقدم للبرامج؟</h2>
          <p className="text-gray-500 max-w-lg mx-auto">4 خطوات بسيطة تفصلك عن الحصول على الدعم الذي تستحقه</p>
        </motion.div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {STEPS.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.45 }}
                className="relative text-center"
              >
                {i < STEPS.length - 1 && (
                  <div className="hidden lg:block absolute top-7 left-0 w-full h-px border-t-2 border-dashed border-gray-200 -translate-x-1/2" />
                )}
                <div className="relative inline-flex">
                  <div className="w-14 h-14 rounded-2xl bg-[#2D6A4F] flex items-center justify-center mx-auto mb-4 shadow-md">
                    <Icon size={22} className="text-white" />
                  </div>
                  <span className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-[#FFB703] text-[#212529] text-xs flex items-center justify-center shadow">
                    {i + 1}
                  </span>
                </div>
                <h3 className="text-[#212529] mb-2 text-base">{step.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{step.desc}</p>
              </motion.div>
            );
          })}
        </div>
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Link
            to="/request"
            className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors shadow-lg font-medium"
          >
            ابدأ التسجيل الآن
            <ArrowLeft size={18} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

function FooterStrip() {
  return (
    <footer className="bg-[#212529] py-6">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-400 text-sm">
        <p>© 2026 منصة إسناد — جميع الحقوق محفوظة</p>
        <div className="flex gap-6">
          <Link to="/about" className="hover:text-white transition-colors">من نحن</Link>
          <Link to="/contact" className="hover:text-white transition-colors">تواصل معنا</Link>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function ProgramsPage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />
      <HeroPrograms />
      <ProgramsGrid />
      <HowToApply />
      <FooterStrip />
    </div>
  );
}
