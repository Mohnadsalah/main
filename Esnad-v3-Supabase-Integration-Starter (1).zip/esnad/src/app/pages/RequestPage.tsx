import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router';
import {
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  Upload,
  Utensils,
  Stethoscope,
  GraduationCap,
  Home,
  Brain,
  Banknote,
  Shirt,
  Wrench,
  AlertCircle,
  Phone,
  User,
  MapPin,
  Users,
  FileText,
  X,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';
import { submitRequest } from '../services';
import { getSupabase, isSupabaseConfigured } from '../supabase';

/* ─────────────────────────── Data ──────────────────────────── */
const PROGRAMS = [
  { id: 'food',      icon: Utensils,      label: 'مساعدة غذائية',  desc: 'سلة غذائية شهرية للأسرة',       color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200' },
  { id: 'medical',   icon: Stethoscope,   label: 'رعاية طبية',      desc: 'علاج وأدوية وفحوصات',           color: 'text-rose-600',   bg: 'bg-rose-50',   border: 'border-rose-200'   },
  { id: 'education', icon: GraduationCap, label: 'دعم تعليمي',      desc: 'رسوم ومستلزمات مدرسية',        color: 'text-blue-600',   bg: 'bg-blue-50',   border: 'border-blue-200'   },
  { id: 'housing',   icon: Home,          label: 'مساعدة إيواء',    desc: 'دعم الإيجار والصيانة',          color: 'text-[#2D6A4F]',  bg: 'bg-[#e8f5ef]', border: 'border-[#c5e8d8]'  },
  { id: 'mental',    icon: Brain,         label: 'دعم نفسي',         desc: 'جلسات إرشاد مع متخصصين',       color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-200' },
  { id: 'financial', icon: Banknote,      label: 'مساعدة مالية',    desc: 'تحويل نقدي مباشر للأسرة',      color: 'text-amber-600',  bg: 'bg-amber-50',  border: 'border-amber-200'  },
  { id: 'clothing',  icon: Shirt,         label: 'كسوة موسمية',     desc: 'ملابس شتوية وصيفية للأطفال',   color: 'text-cyan-600',   bg: 'bg-cyan-50',   border: 'border-cyan-200'   },
  { id: 'equipment', icon: Wrench,        label: 'معدات منزلية',    desc: 'أثاث وأجهزة كهربائية أساسية',  color: 'text-gray-600',   bg: 'bg-gray-100',  border: 'border-gray-200'   },
];

const REGIONS = ['الرياض', 'مكة المكرمة', 'المدينة المنورة', 'المنطقة الشرقية', 'عسير', 'تبوك', 'القصيم', 'جازان', 'جرش', 'عجلون', 'الطفيلة', 'معان'];

const STEPS = ['فحص الأهلية', 'اختر البرنامج', 'بياناتك الشخصية', 'المستندات', 'المراجعة'];

/* ─────────────────────────── Step Indicator ────────────────── */
function StepIndicator({ current }: { current: number }) {
  return (
    <div className="flex items-center justify-center gap-0 mb-10 overflow-x-auto pb-1">
      {STEPS.map((label, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <div key={label} className="flex items-center flex-shrink-0">
            <div className="flex flex-col items-center">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm transition-all duration-300
                ${done   ? 'bg-[#2D6A4F] text-white shadow-md'
                : active ? 'bg-[#FFB703] text-[#212529] shadow-md ring-4 ring-[#FFB703]/20'
                :          'bg-gray-100 text-gray-400'}`}
              >
                {done ? <CheckCircle size={16} /> : i + 1}
              </div>
              <span className={`mt-1.5 text-xs whitespace-nowrap hidden sm:block ${active ? 'text-[#2D6A4F]' : done ? 'text-gray-500' : 'text-gray-300'}`}>
                {label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`w-10 sm:w-16 h-px mx-1 transition-colors duration-300 ${done ? 'bg-[#2D6A4F]' : 'bg-gray-200'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ─────────────────────────── Step 1: Eligibility ───────────── */
type EligibilityForm = { region: string; familySize: string; hasIncome: string; monthlyIncome: string; urgent: boolean };

function Step1({ data, onChange }: { data: EligibilityForm; onChange: (d: EligibilityForm) => void }) {
  return (
    <motion.div key="s1" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-5">
      <div className="bg-[#e8f5ef] border border-[#c5e8d8] rounded-2xl p-4 flex items-start gap-3">
        <CheckCircle size={18} className="text-[#2D6A4F] flex-shrink-0 mt-0.5" />
        <p className="text-[#2D6A4F] text-sm leading-relaxed">
          هذا الاستبيان سري ويساعدنا في تقييم احتياجاتك وتوجيهك للبرنامج الأنسب. لن تُشارك بياناتك مع أي جهة خارجية.
        </p>
      </div>
      <div className="grid sm:grid-cols-2 gap-5">
        <div>
          <label className="text-sm text-gray-700 mb-1.5 block">المحافظة / المنطقة *</label>
          <select required value={data.region} onChange={e => onChange({ ...data, region: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]">
            <option value="">اختر محافظتك...</option>
            {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm text-gray-700 mb-1.5 block">عدد أفراد الأسرة *</label>
          <input type="number" min={1} max={20} required value={data.familySize}
            onChange={e => onChange({ ...data, familySize: e.target.value })}
            placeholder="مثال: 5"
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
        </div>
        <div>
          <label className="text-sm text-gray-700 mb-1.5 block">هل يوجد دخل شهري للأسرة؟ *</label>
          <div className="flex gap-3">
            {['نعم', 'لا'].map(opt => (
              <button key={opt} type="button" onClick={() => onChange({ ...data, hasIncome: opt })}
                className={`flex-1 py-3 rounded-xl border text-sm transition-all ${data.hasIncome === opt ? 'border-[#2D6A4F] bg-[#e8f5ef] text-[#2D6A4F]' : 'border-gray-200 bg-gray-50 text-gray-600 hover:border-gray-300'}`}>
                {opt}
              </button>
            ))}
          </div>
        </div>
        {data.hasIncome === 'نعم' && (
          <div>
            <label className="text-sm text-gray-700 mb-1.5 block">الدخل الشهري التقريبي (ر.س)</label>
            <input type="number" value={data.monthlyIncome}
              onChange={e => onChange({ ...data, monthlyIncome: e.target.value })}
              placeholder="مثال: 250"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
          </div>
        )}
      </div>
      <label className="flex items-start gap-3 cursor-pointer p-4 rounded-xl border border-gray-200 hover:border-[#FFB703] transition-colors group">
        <input type="checkbox" checked={data.urgent} onChange={e => onChange({ ...data, urgent: e.target.checked })}
          className="w-4 h-4 mt-0.5 accent-[#2D6A4F]" />
        <div>
          <span className="text-sm text-[#212529] block">حالة طارئة تستوجب تدخلاً فورياً</span>
          <span className="text-xs text-gray-400">مثل انعدام الغذاء التام، حالة طبية حرجة، أو فقدان المسكن</span>
        </div>
      </label>
    </motion.div>
  );
}

/* ─────────────────────────── Step 2: Program Choice ────────── */
function Step2({ selected, onSelect }: { selected: string[]; onSelect: (ids: string[]) => void }) {
  const toggle = (id: string) => {
    onSelect(selected.includes(id) ? selected.filter(s => s !== id) : [...selected, id]);
  };
  return (
    <motion.div key="s2" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-4">
      <p className="text-gray-500 text-sm">اختر نوع المساعدة أو أكثر من نوع حسب احتياجك (يمكن اختيار أكثر من برنامج)</p>
      <div className="grid sm:grid-cols-2 gap-3">
        {PROGRAMS.map(prog => {
          const Icon = prog.icon;
          const active = selected.includes(prog.id);
          return (
            <button key={prog.id} type="button" onClick={() => toggle(prog.id)}
              className={`flex items-center gap-4 p-4 rounded-2xl border text-right transition-all duration-200
                ${active ? `${prog.border} ${prog.bg} shadow-sm` : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${active ? prog.bg : 'bg-gray-100'}`}>
                <Icon size={18} className={active ? prog.color : 'text-gray-400'} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${active ? 'text-[#212529]' : 'text-gray-600'}`}>{prog.label}</p>
                <p className="text-xs text-gray-400 mt-0.5">{prog.desc}</p>
              </div>
              {active && <CheckCircle size={16} className={prog.color} />}
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Step 3: Personal Info ─────────── */
type PersonForm = { fullName: string; nationalId: string; phone: string; address: string; maritalStatus: string; notes: string };

function Step3({ data, onChange }: { data: PersonForm; onChange: (d: PersonForm) => void }) {
  return (
    <motion.div key="s3" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-5">
      <div className="grid sm:grid-cols-2 gap-5">
        {[
          { key: 'fullName',   label: 'الاسم الكامل *',      icon: User,     type: 'text',  placeholder: 'الاسم الرباعي كما في الهوية' },
          { key: 'nationalId', label: 'رقم الهوية الوطنية *', icon: FileText, type: 'text',  placeholder: '10 أرقام' },
          { key: 'phone',      label: 'رقم الهاتف *',         icon: Phone,    type: 'tel',   placeholder: '+966 5X XXX XXXX' },
          { key: 'address',    label: 'العنوان التفصيلي *',   icon: MapPin,   type: 'text',  placeholder: 'الشارع والمبنى والحي' },
        ].map(({ key, label, icon: Icon, type, placeholder }) => (
          <div key={key}>
            <label className="flex items-center gap-1.5 text-sm text-gray-700 mb-1.5">
              <Icon size={13} className="text-gray-400" /> {label}
            </label>
            <input type={type} required value={data[key as keyof PersonForm]}
              onChange={e => onChange({ ...data, [key]: e.target.value })}
              placeholder={placeholder}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
          </div>
        ))}
        <div>
          <label className="flex items-center gap-1.5 text-sm text-gray-700 mb-1.5">
            <Users size={13} className="text-gray-400" /> الحالة الاجتماعية *
          </label>
          <select required value={data.maritalStatus} onChange={e => onChange({ ...data, maritalStatus: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]">
            <option value="">اختر...</option>
            {['أعزب', 'متزوج', 'مطلق', 'أرمل', 'معيل / معيلة'].map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
      </div>
      <div>
        <label className="text-sm text-gray-700 mb-1.5 block">ملاحظات إضافية (اختياري)</label>
        <textarea rows={3} value={data.notes} onChange={e => onChange({ ...data, notes: e.target.value })}
          placeholder="أي معلومات إضافية تودّ مشاركتها مع فريق المراجعة..."
          className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] resize-none" />
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Step 4: Documents ─────────────── */
type DocState = { nationalId: boolean; familyDoc: boolean; addressProof: boolean; medicalDoc: boolean };

function Step4({ docs, setDocs }: { docs: DocState; setDocs: (d: DocState) => void }) {
  const docList = [
    { key: 'nationalId',   label: 'بطاقة الهوية الوطنية',         required: true,  hint: 'نسخة واضحة من الوجهين' },
    { key: 'familyDoc',    label: 'وثيقة الوضع الأسري / عقد الزواج', required: true,  hint: 'صادرة عن دائرة الأحوال المدنية' },
    { key: 'addressProof', label: 'إثبات العنوان',                   required: true,  hint: 'فاتورة كهرباء أو ماء أو عقد إيجار' },
    { key: 'medicalDoc',   label: 'وثائق طبية (للحالات الصحية)',      required: false, hint: 'تقرير طبي أو وصفة دوائية إن وُجدت' },
  ];
  return (
    <motion.div key="s4" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-4">
      <p className="text-gray-500 text-sm">ارفع المستندات المطلوبة بصيغة PDF أو صورة واضحة (الحد الأقصى 5 ميجابايت لكل ملف)</p>
      {docList.map(({ key, label, required, hint }) => {
        const uploaded = docs[key as keyof DocState];
        return (
          <div key={key}
            className={`flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer
              ${uploaded ? 'bg-[#e8f5ef] border-[#c5e8d8]' : 'bg-white border-gray-200 hover:border-gray-300'}`}
            onClick={() => setDocs({ ...docs, [key]: !uploaded })}
          >
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${uploaded ? 'bg-[#2D6A4F]' : 'bg-gray-100'}`}>
              {uploaded ? <CheckCircle size={20} className="text-white" /> : <Upload size={20} className="text-gray-400" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#212529]">{label}</span>
                {required && <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-50 text-red-500">مطلوب</span>}
              </div>
              <span className="text-xs text-gray-400">{uploaded ? 'تم الرفع ✓' : hint}</span>
            </div>
            {!uploaded && (
              <div className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-gray-100 text-gray-500 text-xs hover:bg-gray-200 transition-colors">
                رفع ملف
              </div>
            )}
          </div>
        );
      })}
      <div className="border-2 border-dashed border-gray-200 rounded-2xl p-6 flex flex-col items-center gap-2 hover:border-[#2D6A4F] transition-colors cursor-pointer group">
        <Upload size={22} className="text-gray-300 group-hover:text-[#2D6A4F] transition-colors" />
        <p className="text-sm text-gray-400 group-hover:text-[#2D6A4F] transition-colors">أو اسحب الملفات هنا</p>
        <p className="text-xs text-gray-300">PDF، JPG، PNG</p>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Step 5: Review ────────────────── */
function Step5({ eligibility, programs, personal }: { eligibility: EligibilityForm; programs: string[]; personal: PersonForm }) {
  const selectedPrograms = PROGRAMS.filter(p => programs.includes(p.id));
  return (
    <motion.div key="s5" initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="space-y-5">
      <div className="bg-[#e8f5ef] border border-[#c5e8d8] rounded-2xl p-4 flex items-start gap-3">
        <AlertCircle size={18} className="text-[#2D6A4F] flex-shrink-0 mt-0.5" />
        <p className="text-[#2D6A4F] text-sm">راجع بياناتك قبل الإرسال النهائي. بعد الإرسال ستتلقى رقم طلب للمتابعة.</p>
      </div>

      {[
        {
          title: 'الأهلية والوضع الأسري',
          rows: [
            ['المنطقة', eligibility.region || '—'],
            ['عدد الأفراد', eligibility.familySize ? `${eligibility.familySize} أفراد` : '—'],
            ['دخل شهري', eligibility.hasIncome || '—'],
            ['حالة طارئة', eligibility.urgent ? 'نعم' : 'لا'],
          ],
        },
        {
          title: 'البيانات الشخصية',
          rows: [
            ['الاسم الكامل', personal.fullName || '—'],
            ['رقم الهاتف', personal.phone || '—'],
            ['العنوان', personal.address || '—'],
            ['الحالة الاجتماعية', personal.maritalStatus || '—'],
          ],
        },
      ].map(section => (
        <div key={section.title} className="bg-white rounded-2xl border border-gray-100 p-5">
          <h4 className="text-[#212529] text-sm mb-3 pb-2 border-b border-gray-100">{section.title}</h4>
          <div className="space-y-2">
            {section.rows.map(([label, val]) => (
              <div key={label} className="flex justify-between text-sm">
                <span className="text-gray-400">{label}</span>
                <span className="text-[#212529]">{val}</span>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <h4 className="text-[#212529] text-sm mb-3 pb-2 border-b border-gray-100">البرامج المختارة</h4>
        <div className="flex flex-wrap gap-2">
          {selectedPrograms.length === 0
            ? <span className="text-gray-400 text-sm">لم تُختَر برامج</span>
            : selectedPrograms.map(p => (
              <span key={p.id} className={`px-3 py-1 rounded-full text-xs ${p.bg} ${p.color} border ${p.border}`}>
                {p.label}
              </span>
            ))}
        </div>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Success ───────────────────────── */
function SuccessScreen({ reqId }: { reqId: string }) {
  const navigate = useNavigate();
  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-10 px-4">
      <div className="w-20 h-20 rounded-full bg-[#e8f5ef] flex items-center justify-center mx-auto mb-6">
        <CheckCircle size={36} className="text-[#2D6A4F]" />
      </div>
      <h2 className="text-2xl text-[#212529] mb-2">تم تقديم طلبك بنجاح!</h2>
      <p className="text-gray-500 mb-4 max-w-sm mx-auto leading-relaxed">
        سيراجع فريقنا طلبك خلال 3–5 أيام عمل وسيتواصل معك على الرقم المسجّل.
      </p>
      <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#e8f5ef] border border-[#c5e8d8] mb-8">
        <FileText size={16} className="text-[#2D6A4F]" />
        <span className="text-[#2D6A4F] text-sm">رقم طلبك: <span className="font-mono">{reqId}</span></span>
      </div>
      <div className="flex flex-wrap justify-center gap-4">
        <button onClick={() => navigate('/dashboard')}
          className="px-6 py-3 rounded-xl bg-[#2D6A4F] text-white hover:bg-[#1f4a37] transition-colors">
          متابعة طلبي
        </button>
        <Link to="/" className="px-6 py-3 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors">
          العودة للرئيسية
        </Link>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function RequestPage() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [submittedRequestId, setSubmittedRequestId] = useState('');
  const [eligibility, setEligibility] = useState<EligibilityForm>({ region: '', familySize: '', hasIncome: '', monthlyIncome: '', urgent: false });
  const [selectedPrograms, setSelectedPrograms] = useState<string[]>([]);
  const [personal, setPersonal] = useState<PersonForm>({ fullName: '', nationalId: '', phone: '', address: '', maritalStatus: '', notes: '' });
  const [docs, setDocs] = useState<DocState>({ nationalId: false, familyDoc: false, addressProof: false, medicalDoc: false });

  const canProceed = () => {
    if (step === 0) return eligibility.region && eligibility.familySize && eligibility.hasIncome;
    if (step === 1) return selectedPrograms.length > 0;
    if (step === 2) return personal.fullName && personal.phone && personal.nationalId && personal.address && personal.maritalStatus;
    if (step === 3) return docs.nationalId && docs.familyDoc && docs.addressProof;
    return true;
  };

  const handleNext = async () => {
    if (step < STEPS.length - 1) { setStep(s => s + 1); return; }
    try {
      if (isSupabaseConfigured) {
        const supabase = getSupabase();
        const { data: { user } } = supabase ? await supabase.auth.getUser() : { data: { user: null } };
        if (!user) { window.location.assign('/login'); return; }
      }
      const saved = await submitRequest({
        type: selectedPrograms.map(id => PROGRAMS.find(program => program.id === id)?.label ?? id).join('، '),
        region: eligibility.region,
        personal,
        eligibility,
        programs: selectedPrograms,
        documents: docs,
      });
      setSubmittedRequestId(saved.id);
      setSubmitted(true);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : 'تعذر حفظ الطلب. تحقق من الاتصال وحاول مجدداً.');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />

      {/* Hero strip */}
      <div className="pt-20 bg-gradient-to-b from-[#2D6A4F] to-[#1f4a37] pb-16">
        <div className="max-w-2xl mx-auto px-6 pt-10 text-center">
          <h1 className="text-3xl text-white mb-2">تقديم طلب مساعدة</h1>
          <p className="text-white/70 text-sm">ملء النموذج لا يستغرق أكثر من 5 دقائق</p>
        </div>
      </div>

      {/* Card */}
      <div className="max-w-2xl mx-auto px-4 -mt-8 pb-16">
        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
          {submitted ? (
            <SuccessScreen reqId={submittedRequestId} />
          ) : (
            <>
              {/* Header */}
              <div className="px-8 pt-8 pb-6 border-b border-gray-100">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-[#212529] text-lg">{STEPS[step]}</h2>
                  <div className="flex items-center gap-1.5">
                    {STEPS.map((_, i) => (
                      <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === step ? 'w-6 bg-[#FFB703]' : i < step ? 'w-3 bg-[#2D6A4F]' : 'w-3 bg-gray-200'}`} />
                    ))}
                  </div>
                </div>
                <StepIndicator current={step} />
              </div>

              {/* Body */}
              <div className="px-8 py-6">
                <AnimatePresence mode="wait">
                  {step === 0 && <Step1 data={eligibility} onChange={setEligibility} />}
                  {step === 1 && <Step2 selected={selectedPrograms} onSelect={setSelectedPrograms} />}
                  {step === 2 && <Step3 data={personal} onChange={setPersonal} />}
                  {step === 3 && <Step4 docs={docs} setDocs={setDocs} />}
                  {step === 4 && <Step5 eligibility={eligibility} programs={selectedPrograms} personal={personal} />}
                </AnimatePresence>
              </div>

              {/* Footer */}
              <div className="px-8 pb-8 flex items-center gap-3">
                {step > 0 && (
                  <button onClick={() => setStep(s => s - 1)}
                    className="flex items-center gap-2 px-5 py-3 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors text-sm">
                    <ChevronRight size={16} />
                    السابق
                  </button>
                )}
                <button onClick={handleNext} disabled={!canProceed()}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-sm text-sm font-medium">
                  {step === STEPS.length - 1 ? 'إرسال الطلب' : 'التالي'}
                  {step < STEPS.length - 1 && <ChevronLeft size={16} />}
                </button>
              </div>
            </>
          )}
        </div>

        {!submitted && (
          <p className="text-center text-gray-400 text-xs mt-4">
            بحاجة لمساعدة؟{' '}
            <Link to="/contact" className="text-[#2D6A4F] hover:underline">تواصل مع فريق الدعم</Link>
          </p>
        )}
      </div>
    </div>
  );
}
