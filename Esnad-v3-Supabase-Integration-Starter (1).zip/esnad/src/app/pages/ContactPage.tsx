import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Send,
  CheckCircle,
  ChevronDown,
  Sparkles,
  MessageCircle,
  Building2,
  ArrowLeft,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';

/* ─────────────────────────── Data ──────────────────────────── */
const CONTACT_CARDS = [
  {
    icon: Phone,
    title: 'الهاتف والواتساب',
    lines: ['+966 11 500 1234', '+966 55 500 5678'],
    sub: 'متاح من الأحد إلى الخميس',
    bg: 'bg-[#e8f5ef]',
    iconColor: 'text-[#2D6A4F]',
    border: 'border-[#c5e8d8]',
  },
  {
    icon: Mail,
    title: 'البريد الإلكتروني',
    lines: ['support@esnad.jo', 'info@esnad.jo'],
    sub: 'نرد خلال 24 ساعة',
    bg: 'bg-blue-50',
    iconColor: 'text-blue-600',
    border: 'border-blue-100',
  },
  {
    icon: MapPin,
    title: 'المقر الرئيسي',
    lines: ['شارع المدينة المنورة', 'الرياض، الأردن 11180'],
    sub: 'الطابق الثالث، مبنى إسناد',
    bg: 'bg-amber-50',
    iconColor: 'text-amber-600',
    border: 'border-amber-100',
  },
  {
    icon: Clock,
    title: 'ساعات العمل',
    lines: ['الأحد – الخميس: 8:00ص – 5:00م', 'السبت: 9:00ص – 1:00م'],
    sub: 'مغلق الجمعة والأعياد الرسمية',
    bg: 'bg-purple-50',
    iconColor: 'text-purple-600',
    border: 'border-purple-100',
  },
];

const OFFICES = [
  { city: 'الرياض',    address: 'شارع المدينة المنورة، مبنى 45',    phone: '06 500 1234', hours: '8:00ص – 5:00م' },
  { city: 'مكة المكرمة',    address: 'شارع الجامعة، مقابل البنك العربي',   phone: '02 720 3456', hours: '8:00ص – 4:00م' },
  { city: 'المدينة المنورة', address: 'شارع الأمير الحسن، مجمع الخدمات',   phone: '05 380 7890', hours: '8:00ص – 4:00م' },
  { city: 'عسير',  address: 'دوار الساعة، مبنى البلدية الجديد',   phone: '02 623 1122', hours: '8:00ص – 3:00م' },
];

const FAQS = [
  {
    q: 'كيف أعرف إذا كنت مؤهلاً للمساعدة؟',
    a: 'يمكنك استخدام أداة الأهلية الذاتية في منصتنا بعد التسجيل. سيُطرح عليك عدد من الأسئلة حول وضعك الأسري والمالي، وستحصل على نتيجة فورية. يمكنك أيضاً التواصل مع فريقنا مباشرةً.',
  },
  {
    q: 'كم يستغرق معالجة الطلب؟',
    a: 'يُعالَج طلبك خلال 3 إلى 5 أيام عمل في المعتاد. الحالات الطارئة تُعطى أولوية وقد تُحسم خلال 24 ساعة. ستتلقى إشعاراً بكل تحديث على هاتفك.',
  },
  {
    q: 'هل يمكنني التقدم لأكثر من برنامج في آنٍ واحد؟',
    a: 'نعم، يمكنك التقدم لعدة برامج في نفس الوقت إذا كانت احتياجاتك تستوجب ذلك. يراجع فريقنا الطلبات بشكل مستقل لكل برنامج.',
  },
  {
    q: 'ماذا لو رُفض طلبي؟',
    a: 'ستتلقى رسالة تشرح سبب الرفض وتُوضّح ما يمكن تحسينه. يحق لك إعادة التقديم بعد تصحيح الوثائق أو تقديم معلومات إضافية في أي وقت.',
  },
  {
    q: 'هل بياناتي محمية وسرية؟',
    a: 'نعم. نلتزم بأعلى معايير حماية البيانات ونستخدم تشفيراً من الطرف إلى الطرف. بياناتك لا تُشارك مع أي جهة إلا بموافقتك الصريحة.',
  },
  {
    q: 'كيف أتبرع أو أصبح شريكاً؟',
    a: 'يسعدنا انضمامك! أرسل لنا بريداً إلكترونياً على partners@esnad.jo أو استخدم نموذج التواصل في هذه الصفحة مع اختيار موضوع "الشراكة والتبرع".',
  },
];

const TOPICS = [
  'استفسار عام',
  'مساعدة في التسجيل',
  'متابعة طلب قائم',
  'الشراكة والتبرع',
  'شكوى أو ملاحظة',
  'وسائل الإعلام والصحافة',
];

/* ─────────────────────────── FAQ Item ──────────────────────── */
function FaqItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(false);
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.06 }}
      className="border border-gray-200 rounded-2xl overflow-hidden"
    >
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-6 py-4 text-right hover:bg-gray-50 transition-colors"
      >
        <span className="text-[#212529] text-sm leading-snug">{q}</span>
        <ChevronDown
          size={18}
          className={`flex-shrink-0 mr-4 text-gray-400 transition-transform duration-300 ${open ? 'rotate-180' : ''}`}
        />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <p className="px-6 pb-5 text-gray-500 text-sm leading-relaxed border-t border-gray-100 pt-4">
              {a}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ─────────────────────────── Contact Form ──────────────────── */
function ContactForm() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', topic: '', message: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); setSent(true); }, 1200);
  };

  if (sent) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center py-14 text-center"
      >
        <div className="w-16 h-16 rounded-full bg-[#e8f5ef] flex items-center justify-center mb-4">
          <CheckCircle size={30} className="text-[#2D6A4F]" />
        </div>
        <h3 className="text-[#212529] text-xl mb-2">تم إرسال رسالتك!</h3>
        <p className="text-gray-500 text-sm mb-6 max-w-sm">
          شكراً للتواصل معنا. سيرد عليك أحد أعضاء فريقنا خلال 24 ساعة على أقصى تقدير.
        </p>
        <button
          onClick={() => { setSent(false); setForm({ name: '', phone: '', email: '', topic: '', message: '' }); }}
          className="px-6 py-2.5 rounded-xl border border-[#2D6A4F] text-[#2D6A4F] hover:bg-[#e8f5ef] transition-colors text-sm"
        >
          إرسال رسالة جديدة
        </button>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-gray-500 mb-1.5 block">الاسم الكامل *</label>
          <input
            required
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            placeholder="موضي إبراهيم"
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
          />
        </div>
        <div>
          <label className="text-xs text-gray-500 mb-1.5 block">رقم الهاتف *</label>
          <input
            required
            type="tel"
            value={form.phone}
            onChange={e => setForm({ ...form, phone: e.target.value })}
            placeholder="+966 5X XXX XXXX"
            className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-gray-500 mb-1.5 block">البريد الإلكتروني</label>
        <input
          type="email"
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
          placeholder="example@email.com"
          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
        />
      </div>

      <div>
        <label className="text-xs text-gray-500 mb-1.5 block">موضوع التواصل *</label>
        <select
          required
          value={form.topic}
          onChange={e => setForm({ ...form, topic: e.target.value })}
          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors"
        >
          <option value="">اختر موضوع التواصل...</option>
          {TOPICS.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      </div>

      <div>
        <label className="text-xs text-gray-500 mb-1.5 block">رسالتك *</label>
        <textarea
          required
          rows={5}
          value={form.message}
          onChange={e => setForm({ ...form, message: e.target.value })}
          placeholder="اكتب رسالتك هنا بالتفصيل..."
          className="w-full px-4 py-2.5 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] transition-colors resize-none"
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] disabled:opacity-60 transition-all shadow-sm font-medium"
      >
        {loading ? (
          <span className="w-5 h-5 rounded-full border-2 border-[#212529]/30 border-t-[#212529] animate-spin" />
        ) : (
          <>
            <Send size={16} />
            إرسال الرسالة
          </>
        )}
      </button>
    </form>
  );
}

/* ─────────────────────────── Sections ──────────────────────── */
function HeroContact() {
  return (
    <section className="relative min-h-[44vh] flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-[#2D6A4F] via-[#1f4a37] to-[#2D6A4F]" />
      <div className="absolute inset-0 opacity-10">
        <div className="absolute bottom-0 right-1/3 w-72 h-72 rounded-full bg-[#A9D6E5] blur-3xl" />
      </div>
      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 w-full py-14">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 mb-6"
        >
          <Sparkles size={14} className="text-[#FFB703]" />
          <span className="text-white/80 text-sm">تواصل معنا</span>
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl lg:text-5xl text-white mb-4 leading-tight"
        >
          نحن هنا من أجلك،
          <span className="block text-[#FFB703]">تحدّث معنا</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-white/70 text-lg max-w-xl leading-relaxed"
        >
          سواء كان لديك سؤال أو بحاجة لمساعدة أو تريد الشراكة معنا — فريقنا يتطلع لسماعك.
        </motion.p>
      </div>
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 50" fill="none"><path d="M0 50L1440 50L1440 15C1200 50 960 0 720 15C480 30 240 0 0 15Z" fill="#F8F9FA" /></svg>
      </div>
    </section>
  );
}

function ContactCards() {
  return (
    <section className="py-12 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {CONTACT_CARDS.map((card, i) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.4 }}
                className={`rounded-2xl border p-5 ${card.bg} ${card.border} hover:shadow-md transition-shadow`}
              >
                <div className="w-11 h-11 rounded-xl bg-white/60 flex items-center justify-center mb-4">
                  <Icon size={20} className={card.iconColor} />
                </div>
                <h3 className="text-[#212529] text-sm mb-2">{card.title}</h3>
                {card.lines.map(line => (
                  <p key={line} className="text-[#212529] text-sm">{line}</p>
                ))}
                <p className="text-gray-400 text-xs mt-2">{card.sub}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function FormAndFaq() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-9 h-9 rounded-xl bg-[#e8f5ef] flex items-center justify-center">
                <MessageCircle size={18} className="text-[#2D6A4F]" />
              </div>
              <div>
                <h2 className="text-2xl text-[#212529]">أرسل لنا رسالة</h2>
                <p className="text-gray-400 text-xs">سنردّ خلال يوم عمل واحد</p>
              </div>
            </div>
            <div className="bg-[#F8F9FA] rounded-2xl border border-gray-100 p-6">
              <ContactForm />
            </div>
          </motion.div>

          {/* FAQ */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h2 className="text-2xl text-[#212529] mb-2">الأسئلة الشائعة</h2>
            <p className="text-gray-400 text-sm mb-6">إجابات لأكثر ما يُسأل عنه</p>
            <div className="space-y-3">
              {FAQS.map((faq, i) => (
                <FaqItem key={i} q={faq.q} a={faq.a} index={i} />
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function OfficesSection() {
  return (
    <section className="py-16 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl text-[#212529] mb-2">مكاتبنا الميدانية</h2>
          <p className="text-gray-500">نحن قريبون منك في 4 محافظات</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {OFFICES.map((office, i) => (
            <motion.div
              key={office.city}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl bg-[#2D6A4F] flex items-center justify-center flex-shrink-0">
                  <Building2 size={16} className="text-white" />
                </div>
                <h3 className="text-[#212529]">{office.city}</h3>
              </div>
              <div className="space-y-2.5 text-sm">
                <div className="flex items-start gap-2 text-gray-500">
                  <MapPin size={13} className="mt-0.5 flex-shrink-0 text-gray-400" />
                  {office.address}
                </div>
                <div className="flex items-center gap-2 text-gray-500">
                  <Phone size={13} className="flex-shrink-0 text-gray-400" />
                  <span dir="ltr">{office.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-500">
                  <Clock size={13} className="flex-shrink-0 text-gray-400" />
                  {office.hours}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Map placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-8 rounded-2xl overflow-hidden border border-gray-200 bg-gradient-to-br from-[#e8f5ef] to-[#A9D6E5]/20 h-56 flex items-center justify-center"
        >
          <div className="text-center">
            <div className="w-12 h-12 rounded-2xl bg-[#2D6A4F] flex items-center justify-center mx-auto mb-3">
              <MapPin size={20} className="text-white" />
            </div>
            <p className="text-[#2D6A4F] text-sm">خريطة مكاتب إسناد</p>
            <p className="text-gray-400 text-xs mt-1">4 مكاتب ميدانية عبر المملكة</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function CTAStrip() {
  return (
    <section className="py-16 bg-gradient-to-br from-[#2D6A4F] to-[#1f4a37] relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-[#FFB703] blur-3xl" />
      </div>
      <div className="relative max-w-3xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl text-white mb-3">جاهز للبدء؟</h2>
          <p className="text-white/70 mb-6">سجّل الآن وابدأ رحلتك معنا في دقائق</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/request"
              className="inline-flex items-center gap-2 px-7 py-3 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors shadow-lg font-medium"
            >
              سجّل الآن
              <ArrowLeft size={16} />
            </Link>
            <Link
              to="/programs"
              className="inline-flex items-center gap-2 px-7 py-3 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
            >
              تصفّح البرامج
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function FooterStrip() {
  return (
    <footer className="bg-[#212529] py-6">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-400 text-sm">
        <p>© 2026 منصة إسناد — جميع الحقوق محفوظة</p>
        <div className="flex gap-6">
          <Link to="/about" className="hover:text-white transition-colors">من نحن</Link>
          <Link to="/programs" className="hover:text-white transition-colors">البرامج</Link>
          <Link to="/impact" className="hover:text-white transition-colors">الأثر</Link>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function ContactPage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />
      <HeroContact />
      <ContactCards />
      <FormAndFaq />
      <OfficesSection />
      <CTAStrip />
      <FooterStrip />
    </div>
  );
}
