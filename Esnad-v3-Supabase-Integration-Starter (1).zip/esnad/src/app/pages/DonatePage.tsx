import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';
import {
  Heart,
  CheckCircle,
  CreditCard,
  Repeat,
  ArrowLeft,
  Sparkles,
  Users,
  Utensils,
  GraduationCap,
  Stethoscope,
  Lock,
  TrendingUp,
  Quote,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';

/* ─────────────────────────── Data ──────────────────────────── */
const PRESET_AMOUNTS = [25, 50, 100, 250, 500, 1000];

const IMPACT_PER_AMOUNT: Record<number, string> = {
  25:   'توفير وجبات غذائية أساسية لأسرة لمدة أسبوع',
  50:   'تغطية رسوم مدرسية لطفل لمدة شهر كامل',
  100:  'توفير سلة غذائية شاملة لأسرة لمدة شهر',
  250:  'تمويل جلسات دعم نفسي لأسرة محتاجة',
  500:  'تغطية نفقات علاج طبي لحالة مزمنة',
  1000: 'دعم أسرة كاملة لمدة 3 أشهر شاملاً',
};

const WHERE_IT_GOES = [
  { pct: 72, label: 'مباشرة للمستفيدين',   desc: 'طعام وعلاج وتعليم وإيواء',              color: 'bg-[#2D6A4F]',  icon: Heart   },
  { pct: 15, label: 'خدمات التسليم',        desc: 'لوجستيات وتوزيع ميداني',                color: 'bg-[#A9D6E5]',  icon: Users   },
  { pct: 8,  label: 'التقنية والبنية التحتية', desc: 'تطوير المنصة وأنظمة الشفافية',       color: 'bg-[#FFB703]',  icon: TrendingUp },
  { pct: 5,  label: 'إدارة وتدقيق',         desc: 'محاسبة ومراجعة ورقابة',                 color: 'bg-gray-300',   icon: CheckCircle },
];

const DONORS = [
  { initials: 'م.ع', amount: 500,  time: 'منذ دقيقتين',   program: 'مساعدة غذائية' },
  { initials: 'س.أ', amount: 100,  time: 'منذ 8 دقائق',   program: 'دعم تعليمي'    },
  { initials: 'ر.خ', amount: 250,  time: 'منذ 15 دقيقة',  program: 'رعاية طبية'    },
  { initials: 'ف.م', amount: 1000, time: 'منذ 23 دقيقة',  program: 'متعدد البرامج'  },
];

const TESTIMONIALS = [
  { name: 'محمد — الرياض', text: 'كل ريال يصل فعلاً. تلقيت رسالة تأكيد بأن تبرعي أعان أسرة في عسير خلال 24 ساعة.' },
  { name: 'لمى — مكة المكرمة',   text: 'أتبرع شهرياً منذ عامين. الشفافية الكاملة في تقارير الأثر هي ما يجعلني أثق بإسناد.' },
];

/* ─────────────────────────── Impact Bar ────────────────────── */
function ImpactBar({ item, index }: { item: typeof WHERE_IT_GOES[0]; index: number }) {
  const Icon = item.icon;
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      className="flex items-center gap-4"
    >
      <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0">
        <Icon size={16} className="text-gray-500" />
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm text-[#212529]">{item.label}</span>
          <span className="text-sm text-[#2D6A4F]">{item.pct}%</span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${item.pct}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: index * 0.1 }}
            className={`h-full ${item.color} rounded-full`}
          />
        </div>
        <p className="text-xs text-gray-400 mt-0.5">{item.desc}</p>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────── Donation Form ─────────────────── */
function DonationForm() {
  const [amount, setAmount] = useState<number>(100);
  const [custom, setCustom] = useState('');
  const [recurring, setRecurring] = useState(false);
  const [program, setProgram] = useState('أي برنامج');
  const [step, setStep] = useState<'amount' | 'payment' | 'done'>('amount');
  const [name, setName] = useState('');
  const [cardNum, setCardNum] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);

  const finalAmount = custom ? Number(custom) : amount;

  const handlePay = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); setStep('done'); }, 1400);
  };

  if (step === 'done') {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-10">
        <div className="w-20 h-20 rounded-full bg-[#e8f5ef] flex items-center justify-center mx-auto mb-5">
          <Heart size={32} className="text-[#2D6A4F]" />
        </div>
        <h3 className="text-2xl text-[#212529] mb-2">شكراً لتبرعك!</h3>
        <p className="text-gray-500 text-sm mb-2">تبرعك بمبلغ <span className="text-[#2D6A4F]">{finalAmount} ر.س</span> تم استلامه.</p>
        <p className="text-gray-400 text-xs mb-6">ستصلك رسالة تأكيد على بريدك الإلكتروني مع تفاصيل الأثر خلال 48 ساعة.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <button onClick={() => { setStep('amount'); setCustom(''); setAmount(100); setCardNum(''); setExpiry(''); setCvv(''); setName(''); }}
            className="px-5 py-2.5 rounded-xl bg-[#2D6A4F] text-white text-sm hover:bg-[#1f4a37] transition-colors">
            تبرع مجدداً
          </button>
          <Link to="/" className="px-5 py-2.5 rounded-xl border border-gray-200 text-gray-600 text-sm hover:bg-gray-50 transition-colors">
            العودة للرئيسية
          </Link>
        </div>
      </motion.div>
    );
  }

  return (
    <div>
      {/* Toggle tabs */}
      <div className="flex items-center gap-1 bg-gray-100 rounded-xl p-1 mb-6">
        {(['amount', 'payment'] as const).map(s => (
          <button key={s} onClick={() => s === 'amount' && setStep('amount')}
            className={`flex-1 py-2 rounded-lg text-sm transition-all ${step === s ? 'bg-white text-[#212529] shadow-sm' : 'text-gray-500'}`}>
            {s === 'amount' ? 'مبلغ التبرع' : 'بيانات الدفع'}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 'amount' ? (
          <motion.div key="amount" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
            {/* Preset amounts */}
            <div>
              <label className="text-sm text-gray-700 mb-2 block">اختر المبلغ (ر.س)</label>
              <div className="grid grid-cols-3 gap-2">
                {PRESET_AMOUNTS.map(val => (
                  <button key={val} type="button"
                    onClick={() => { setAmount(val); setCustom(''); }}
                    className={`py-2.5 rounded-xl text-sm border transition-all ${amount === val && !custom ? 'bg-[#2D6A4F] text-white border-[#2D6A4F] shadow-sm' : 'bg-white text-gray-600 border-gray-200 hover:border-[#2D6A4F]'}`}>
                    {val}
                  </button>
                ))}
              </div>
            </div>
            {/* Custom amount */}
            <div>
              <label className="text-sm text-gray-700 mb-1.5 block">أو أدخل مبلغاً مخصصاً</label>
              <div className="relative">
                <input type="number" min={1} value={custom} onChange={e => { setCustom(e.target.value); setAmount(0); }}
                  placeholder="مثال: 75"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] pr-16" />
                <span className="absolute top-1/2 -translate-y-1/2 right-4 text-gray-400 text-sm">ر.س</span>
              </div>
            </div>
            {/* Program targeting */}
            <div>
              <label className="text-sm text-gray-700 mb-1.5 block">توجيه التبرع (اختياري)</label>
              <select value={program} onChange={e => setProgram(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-[#212529] text-sm focus:outline-none focus:border-[#2D6A4F]">
                {['أي برنامج', 'مساعدة غذائية', 'رعاية طبية', 'دعم تعليمي', 'دعم نفسي', 'مساعدة إيواء'].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            {/* Recurring */}
            <label className="flex items-center justify-between p-4 rounded-xl border border-gray-200 cursor-pointer hover:border-[#2D6A4F] transition-colors">
              <div className="flex items-center gap-3">
                <Repeat size={18} className="text-[#2D6A4F]" />
                <div>
                  <span className="text-sm text-[#212529]">تبرع شهري تلقائي</span>
                  <p className="text-xs text-gray-400">يُخصم {finalAmount || amount} ر.س شهرياً تلقائياً</p>
                </div>
              </div>
              <button onClick={() => setRecurring(r => !r)}
                className={`w-11 h-6 rounded-full transition-colors relative ${recurring ? 'bg-[#2D6A4F]' : 'bg-gray-200'}`}>
                <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${recurring ? 'left-1' : 'right-1'}`} />
              </button>
            </label>
            {/* Impact */}
            {(finalAmount || amount) > 0 && (
              <div className="bg-[#e8f5ef] border border-[#c5e8d8] rounded-xl p-4 flex items-start gap-3">
                <Sparkles size={16} className="text-[#2D6A4F] mt-0.5 flex-shrink-0" />
                <p className="text-[#2D6A4F] text-sm leading-relaxed">
                  تبرعك بـ <strong>{finalAmount || amount} ر.س</strong> سيساعد في:{' '}
                  {IMPACT_PER_AMOUNT[finalAmount || amount] ?? 'دعم الأسر المحتاجة في برامج متعددة'}
                </p>
              </div>
            )}
            <button onClick={() => setStep('payment')} disabled={!(finalAmount || amount)}
              className="w-full py-3.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] disabled:opacity-40 transition-all shadow-sm font-medium flex items-center justify-center gap-2">
              <CreditCard size={18} />
              متابعة للدفع
            </button>
          </motion.div>
        ) : (
          <motion.div key="payment" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
            <div className="bg-[#2D6A4F] rounded-xl p-4 flex items-center justify-between">
              <span className="text-white/80 text-sm">المبلغ الإجمالي</span>
              <span className="text-white text-lg">{finalAmount || amount} ر.س {recurring && <span className="text-white/60 text-sm">/ شهر</span>}</span>
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-1.5 block">الاسم على البطاقة *</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="كما هو مكتوب على البطاقة"
                className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-1.5 block">رقم البطاقة *</label>
              <div className="relative">
                <input value={cardNum} onChange={e => setCardNum(e.target.value.replace(/\D/g, '').slice(0, 16))}
                  placeholder="0000 0000 0000 0000" dir="ltr"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F] pl-12" />
                <CreditCard size={16} className="absolute top-1/2 -translate-y-1/2 left-4 text-gray-400" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-700 mb-1.5 block">تاريخ الانتهاء *</label>
                <input value={expiry} onChange={e => setExpiry(e.target.value)} placeholder="MM/YY" dir="ltr"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
              </div>
              <div>
                <label className="text-sm text-gray-700 mb-1.5 block">CVV *</label>
                <input value={cvv} onChange={e => setCvv(e.target.value.slice(0, 3))} placeholder="123" dir="ltr" type="password"
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 text-sm focus:outline-none focus:border-[#2D6A4F] focus:ring-1 focus:ring-[#2D6A4F]" />
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-gray-400 bg-gray-50 rounded-xl p-3">
              <Lock size={12} className="flex-shrink-0" />
              بياناتك محمية بتشفير SSL 256-bit. لن تُخزَّن بيانات بطاقتك على خوادمنا.
            </div>
            <div className="flex gap-3">
              <button onClick={() => setStep('amount')}
                className="px-4 py-3 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors text-sm">
                رجوع
              </button>
              <button onClick={handlePay} disabled={!name || cardNum.length < 16 || !expiry || cvv.length < 3 || loading}
                className="flex-1 py-3 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] disabled:opacity-40 transition-all shadow-sm font-medium flex items-center justify-center gap-2">
                {loading ? <span className="w-5 h-5 rounded-full border-2 border-[#212529]/30 border-t-[#212529] animate-spin" />
                  : <><Heart size={16} /> أتبرع بـ {finalAmount || amount} ر.س</>}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function DonatePage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />

      {/* Hero */}
      <section className="relative pt-20 pb-24 overflow-hidden bg-gradient-to-br from-[#1f4a37] via-[#2D6A4F] to-[#3a8a65]">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 right-1/3 w-80 h-80 rounded-full bg-[#FFB703] blur-3xl" />
          <div className="absolute bottom-0 left-1/4 w-60 h-60 rounded-full bg-[#A9D6E5] blur-3xl" />
        </div>
        <div className="relative max-w-4xl mx-auto px-6 text-center">
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 mb-6">
            <Heart size={14} className="text-[#FFB703]" />
            <span className="text-white/80 text-sm">تبرع الآن</span>
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-4xl lg:text-5xl text-white mb-4 leading-tight">
            تبرعك يصنع فرقاً
            <span className="block text-[#FFB703]">حقيقياً اليوم</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="text-white/70 text-lg max-w-xl mx-auto leading-relaxed mb-8">
            كل ريال تتبرع به يصل مباشرة إلى أسرة محتاجة ويُوثَّق في تقارير شفافة متاحة للجميع.
          </motion.p>
          {/* Mini stats */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="flex flex-wrap justify-center gap-4">
            {[
              { val: '38M+', lbl: 'ريال صُرف' },
              { val: '97%',  lbl: 'يصل للمستفيد مباشرة' },
              { val: '4K+',  lbl: 'متبرع نشط' },
            ].map(({ val, lbl }) => (
              <div key={lbl} className="px-5 py-3 rounded-2xl bg-white/10 border border-white/15 text-center min-w-[100px]">
                <p className="text-xl text-white">{val}</p>
                <p className="text-white/60 text-xs mt-0.5">{lbl}</p>
              </div>
            ))}
          </motion.div>
        </div>
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 50" fill="none"><path d="M0 50L1440 50L1440 15C1200 50 960 0 720 15C480 30 240 0 0 15Z" fill="#F8F9FA" /></svg>
        </div>
      </section>

      {/* Main content */}
      <section className="py-16 bg-[#F8F9FA]">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-10 items-start">
            {/* Donation form - 3 cols */}
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="lg:col-span-3">
              <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-8">
                <h2 className="text-[#212529] text-xl mb-6">قدّم تبرعك</h2>
                <DonationForm />
              </div>
            </motion.div>

            {/* Right column - 2 cols */}
            <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="lg:col-span-2 space-y-6">
              {/* Where it goes */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-[#212529] text-sm mb-5">إلى أين يذهب تبرعك؟</h3>
                <div className="space-y-4">
                  {WHERE_IT_GOES.map((item, i) => <ImpactBar key={item.label} item={item} index={i} />)}
                </div>
              </div>

              {/* Programs */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-[#212529] text-sm mb-4">البرامج المموّلة</h3>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { icon: Utensils,      label: 'غذاء',    color: 'text-orange-500', bg: 'bg-orange-50' },
                    { icon: Stethoscope,   label: 'طب',      color: 'text-rose-500',   bg: 'bg-rose-50'   },
                    { icon: GraduationCap, label: 'تعليم',   color: 'text-blue-500',   bg: 'bg-blue-50'   },
                    { icon: Heart,         label: 'نفسي',    color: 'text-purple-500', bg: 'bg-purple-50' },
                  ].map(({ icon: Icon, label, color, bg }) => (
                    <div key={label} className={`${bg} rounded-xl p-3 flex items-center gap-2`}>
                      <Icon size={14} className={color} />
                      <span className="text-xs text-gray-600">{label}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent donors */}
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
                <h3 className="text-[#212529] text-sm mb-4">آخر التبرعات</h3>
                <div className="space-y-3">
                  {DONORS.map((d, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#2D6A4F] flex items-center justify-center text-white text-xs flex-shrink-0">
                        {d.initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-[#212529]">{d.amount} ر.س — {d.program}</p>
                        <p className="text-[10px] text-gray-400">{d.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <h2 className="text-2xl text-[#212529] text-center mb-8">ماذا يقول متبرعونا</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            {TESTIMONIALS.map((t, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
                transition={{ delay: i * 0.1 }} className="bg-[#F8F9FA] border border-gray-100 rounded-2xl p-6">
                <Quote size={18} className="text-gray-300 mb-3" />
                <p className="text-gray-600 text-sm italic leading-relaxed mb-4">"{t.text}"</p>
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#2D6A4F] flex items-center justify-center text-white text-xs">{t.name[0]}</div>
                  <span className="text-gray-500 text-xs">{t.name}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 bg-[#F8F9FA]">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <p className="text-gray-500 mb-4">هل تريد المساعدة بدلاً من التبرع المالي؟</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#2D6A4F] text-white hover:bg-[#1f4a37] transition-colors text-sm">
              كن متطوعاً
            </Link>
            <Link to="/programs" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-gray-200 text-gray-600 hover:bg-gray-100 transition-colors text-sm">
              <ArrowLeft size={14} />
              تعرّف على برامجنا
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#212529] py-6">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-400 text-sm">
          <p>© 2026 منصة إسناد — جميع الحقوق محفوظة</p>
          <div className="flex gap-6">
            <Link to="/about" className="hover:text-white transition-colors">من نحن</Link>
            <Link to="/contact" className="hover:text-white transition-colors">تواصل معنا</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
