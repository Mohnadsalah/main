import { motion } from 'motion/react';
import { Link } from 'react-router';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  TrendingUp,
  Users,
  MapPin,
  Heart,
  Sparkles,
  ArrowLeft,
  Quote,
} from 'lucide-react';
import { Navigation } from '../components/Navigation';

/* ─────────────────────────── Chart Data ────────────────────── */
const YEARLY_DATA = [
  { year: '2020', beneficiaries: 12, disbursed: 3.2 },
  { year: '2021', beneficiaries: 38, disbursed: 9.8 },
  { year: '2022', beneficiaries: 74, disbursed: 17.5 },
  { year: '2023', beneficiaries: 108, disbursed: 26.1 },
  { year: '2024', beneficiaries: 128, disbursed: 33.4 },
  { year: '2026', beneficiaries: 142, disbursed: 38.2 },
];

const PROGRAM_DIST = [
  { name: 'غذائية',  value: 34, color: '#f97316' },
  { name: 'تعليمية', value: 22, color: '#3b82f6' },
  { name: 'طبية',    value: 16, color: '#f43f5e' },
  { name: 'مالية',   value: 13, color: '#f59e0b' },
  { name: 'إيواء',   value: 10, color: '#2D6A4F'  },
  { name: 'أخرى',    value: 5,  color: '#A9D6E5'  },
];

const REGIONS = [
  { name: 'الرياض',    pct: 38, beneficiaries: '53,960' },
  { name: 'مكة المكرمة',    pct: 19, beneficiaries: '26,980' },
  { name: 'المدينة المنورة', pct: 14, beneficiaries: '19,880' },
  { name: 'عسير',  pct: 12, beneficiaries: '17,040' },
  { name: 'تبوك',   pct: 8,  beneficiaries: '11,360' },
  { name: 'أخرى',   pct: 9,  beneficiaries: '12,780' },
];

const STATS = [
  { value: '142,000+', label: 'مستفيد مسجّل',      icon: Users,      color: 'bg-[#2D6A4F]',    textColor: 'text-white'     },
  { value: '38M+',     label: 'ريال سعودي صُرف',   icon: TrendingUp, color: 'bg-[#FFB703]',    textColor: 'text-[#7a5400]' },
  { value: '8',        label: 'برنامج مساعدة نشط',  icon: Heart,      color: 'bg-[#A9D6E5]',    textColor: 'text-[#1a6b8a]' },
  { value: '220+',     label: 'شريك مؤسسي ومانح',  icon: MapPin,     color: 'bg-white border border-gray-200', textColor: 'text-[#212529]' },
];

const TESTIMONIALS = [
  {
    name: 'أم محمد — مكة المكرمة',
    text: 'بفضل إسناد تمكّنا من إكمال علاج طفلنا. الفريق كان إنسانياً جداً وسريعاً في التجاوب معنا.',
    program: 'الرعاية الطبية',
    color: 'bg-rose-50 border-rose-100',
    dot: 'bg-rose-400',
  },
  {
    name: 'خالد — عسير',
    text: 'السلة الغذائية الشهرية أنقذت عائلتنا في الشتاء. التسجيل كان سهلاً ومتابعة الطلب شفافة تماماً.',
    program: 'المساعدة الغذائية',
    color: 'bg-orange-50 border-orange-100',
    dot: 'bg-orange-400',
  },
  {
    name: 'رنا — الرياض',
    text: 'دعم التعليم غيّر مسيرة أطفالي. الآن ابني في الجامعة ولم يكن ذلك ممكناً بدون إسناد.',
    program: 'الدعم التعليمي',
    color: 'bg-blue-50 border-blue-100',
    dot: 'bg-blue-400',
  },
];

/* ─────────────────────────── Custom Tooltip ────────────────── */
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number; name: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-200 rounded-xl shadow-lg px-4 py-3 text-sm" dir="rtl">
      <p className="text-[#212529] mb-2">{label}</p>
      {payload.map(p => (
        <p key={p.name} className="text-gray-500">
          {p.name === 'beneficiaries' ? 'المستفيدون' : 'المبلغ (م.د)'}:{' '}
          <span className="text-[#2D6A4F]">{p.value}{p.name === 'beneficiaries' ? 'K' : 'M'}</span>
        </p>
      ))}
    </div>
  );
}

/* ─────────────────────────── Sections ──────────────────────── */
function HeroImpact() {
  return (
    <section className="relative min-h-[50vh] flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-bl from-[#1a3d2e] via-[#2D6A4F] to-[#3a8a65]" />
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-[#FFB703] blur-3xl" />
      </div>
      <div className="relative max-w-7xl mx-auto px-6 lg:px-8 w-full py-16">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/20 mb-6"
        >
          <Sparkles size={14} className="text-[#FFB703]" />
          <span className="text-white/80 text-sm">قياس الأثر</span>
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl lg:text-5xl text-white mb-4 leading-tight"
        >
          أرقام حقيقية،
          <span className="block text-[#FFB703]">أثر لا يُمحى</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-white/70 text-lg max-w-2xl leading-relaxed"
        >
          نقيس كل ريال نصرفه وكل أسرة نساعدها. الشفافية في الأثر ليست خياراً — هي أساس ثقتكم بنا.
        </motion.p>
      </div>
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 50" fill="none"><path d="M0 50L1440 50L1440 15C1200 50 960 0 720 15C480 30 240 0 0 15Z" fill="#F8F9FA" /></svg>
      </div>
    </section>
  );
}

function KeyStats() {
  return (
    <section className="py-16 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {STATS.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.45 }}
                className={`${stat.color} rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow`}
              >
                <div className={`w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center mb-3`}>
                  <Icon size={18} className={stat.textColor} />
                </div>
                <p className={`text-3xl mb-0.5 ${stat.textColor}`}>{stat.value}</p>
                <p className={`text-xs opacity-80 ${stat.textColor}`}>{stat.label}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function GrowthChart() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl text-[#212529] mb-2">مسيرة النمو</h2>
          <p className="text-gray-500">عدد المستفيدين (بالألف) والمبالغ المصروفة (بالمليون ر.س) من 2020 إلى 2026</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 items-start">
          {/* Bar Chart */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-2 bg-[#F8F9FA] rounded-2xl p-6 border border-gray-100"
          >
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={YEARLY_DATA} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="year" tick={{ fill: '#9ca3af', fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: '#9ca3af', fontSize: 12 }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(45,106,79,0.05)' }} />
                <Bar dataKey="beneficiaries" name="beneficiaries" fill="#2D6A4F" radius={[6, 6, 0, 0]} />
                <Bar dataKey="disbursed" name="disbursed" fill="#FFB703" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-center gap-6 mt-2">
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span className="w-3 h-3 rounded bg-[#2D6A4F]" />المستفيدون (ألف)
              </div>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span className="w-3 h-3 rounded bg-[#FFB703]" />المبلغ (م.د)
              </div>
            </div>
          </motion.div>

          {/* Program Distribution Donut */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="bg-[#F8F9FA] rounded-2xl p-6 border border-gray-100"
          >
            <h3 className="text-[#212529] text-sm mb-4">توزيع المستفيدين حسب البرنامج</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={PROGRAM_DIST}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                >
                  {PROGRAM_DIST.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Legend
                  iconType="circle"
                  iconSize={8}
                  formatter={(value) => <span style={{ color: '#6b7280', fontSize: 11 }}>{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function RegionalDistribution() {
  return (
    <section className="py-16 bg-[#F8F9FA]">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl text-[#212529] mb-2">التوزيع الجغرافي</h2>
          <p className="text-gray-500">الوصول إلى المستفيدين عبر محافظات المملكة</p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {REGIONS.map((region, i) => (
            <motion.div
              key={region.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <MapPin size={15} className="text-[#2D6A4F]" />
                  <span className="text-[#212529] text-sm">{region.name}</span>
                </div>
                <span className="text-[#2D6A4F] text-sm">{region.pct}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden mb-2">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${region.pct}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: i * 0.08, ease: 'easeOut' }}
                  className="h-full bg-[#2D6A4F] rounded-full"
                />
              </div>
              <p className="text-gray-400 text-xs">{region.beneficiaries} مستفيد</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl text-[#212529] mb-3">كلمات المستفيدين</h2>
          <p className="text-gray-500">الأثر الحقيقي يُقاس بما تقوله قلوبهم</p>
        </motion.div>

        <div className="grid sm:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.45 }}
              className={`rounded-2xl border p-6 ${t.color}`}
            >
              <Quote size={20} className="text-gray-300 mb-4" />
              <p className="text-gray-600 text-sm leading-relaxed mb-5 italic">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full ${t.dot} flex items-center justify-center text-white text-xs`}>
                  {t.name[0]}
                </div>
                <div>
                  <p className="text-[#212529] text-sm">{t.name}</p>
                  <p className="text-gray-400 text-xs">{t.program}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTAImpact() {
  return (
    <section className="py-20 bg-gradient-to-br from-[#2D6A4F] to-[#1f4a37] relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-64 h-64 rounded-full bg-[#FFB703] blur-3xl" />
      </div>
      <div className="relative max-w-3xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl text-white mb-4">كن جزءاً من هذا الأثر</h2>
          <p className="text-white/70 mb-8 text-lg leading-relaxed">
            سواء كنت تحتاج مساعدة أو تريد تقديمها — منصة إسناد هي جسرك.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              to="/request"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-[#FFB703] text-[#212529] hover:bg-[#e6a500] transition-colors shadow-lg font-medium"
            >
              سجّل كمستفيد
              <ArrowLeft size={18} />
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-white/30 text-white hover:bg-white/10 transition-colors"
            >
              كن شريكاً
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function FooterStrip() {
  return (
    <footer className="bg-[#212529] py-6">
      <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-400 text-sm">
        <p>© 2026 منصة إسناد — جميع الحقوق محفوظة</p>
        <div className="flex gap-6">
          <Link to="/about" className="hover:text-white transition-colors">من نحن</Link>
          <Link to="/contact" className="hover:text-white transition-colors">تواصل معنا</Link>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function ImpactPage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA]" dir="rtl">
      <Navigation />
      <HeroImpact />
      <KeyStats />
      <GrowthChart />
      <RegionalDistribution />
      <TestimonialsSection />
      <CTAImpact />
      <FooterStrip />
    </div>
  );
}
