import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckCircle,
  Bell,
  AlertCircle,
  Info,
  FileText,
  Trash2,
  CheckCheck,
  Clock,
  ChevronLeft,
} from 'lucide-react';
import { DashboardShell } from '../components/DashboardShell';

/* ─────────────────────────── Types ─────────────────────────── */
type NotifType = 'aid' | 'alert' | 'info' | 'system';
type FilterTab = 'all' | 'unread' | 'urgent' | 'system';

interface Notification {
  id: number;
  type: NotifType;
  title: string;
  body: string;
  time: string;
  read: boolean;
  urgent: boolean;
}

/* ─────────────────────────── Mock Data ─────────────────────── */
const NOTIFS: Notification[] = [
  {
    id: 1,
    type: 'aid',
    title: 'تمت الموافقة على طلب المساعدة الغذائية',
    body: 'طلبك REQ-2026-001 تمت الموافقة عليه. سيتم التواصل معك لتحديد موعد التسليم خلال يومين.',
    time: 'منذ ساعتين',
    read: false,
    urgent: true,
  },
  {
    id: 2,
    type: 'alert',
    title: 'مستندات ناقصة — يرجى التحديث',
    body: 'طلب المساعدة الإيوائية REQ-2026-004 يحتاج إلى إعادة إرفاق وثيقة الهوية الوطنية.',
    time: 'منذ 5 ساعات',
    read: false,
    urgent: true,
  },
  {
    id: 3,
    type: 'info',
    title: 'تم تحديد موعد الجلسة النفسية',
    body: 'موعدك مع المختص النفسي يوم الخميس 18 أبريل الساعة 10:00 صباحاً في مركز الرياض الرئيسي.',
    time: 'منذ يوم',
    read: false,
    urgent: false,
  },
  {
    id: 4,
    type: 'aid',
    title: 'اكتمل صرف الدعم التعليمي',
    body: 'طلب REQ-2026-003 تم صرفه بنجاح. المبلغ 250 ريال تحويل مباشر لحسابك المسجّل.',
    time: 'منذ يومين',
    read: true,
    urgent: false,
  },
  {
    id: 5,
    type: 'system',
    title: 'تحديث سياسة الخصوصية',
    body: 'تم تحديث سياسة الخصوصية في منصة إسناد. يُرجى الاطلاع عليها والموافقة لاستمرار استخدام المنصة.',
    time: 'منذ 3 أيام',
    read: true,
    urgent: false,
  },
  {
    id: 6,
    type: 'info',
    title: 'برنامج الكسوة الشتوية متاح الآن',
    body: 'أُعلن عن فتح باب التسجيل لبرنامج الكسوة الشتوية 2026. التقديم متاح حتى 30 أبريل.',
    time: 'منذ 4 أيام',
    read: true,
    urgent: false,
  },
  {
    id: 7,
    type: 'aid',
    title: 'طلبك قيد المراجعة',
    body: 'طلب المساعدة المالية REQ-2026-007 وصل فريق المراجعة وسيتم البت فيه خلال 5 أيام عمل.',
    time: 'منذ أسبوع',
    read: true,
    urgent: false,
  },
  {
    id: 8,
    type: 'system',
    title: 'مرحباً بك في منصة إسناد',
    body: 'تم تفعيل حسابك بنجاح. يمكنك الآن تقديم طلبات المساعدة ومتابعة حالتها مباشرة.',
    time: 'منذ شهر',
    read: true,
    urgent: false,
  },
];

/* ─────────────────────────── Config ────────────────────────── */
const TYPE_CONFIG: Record<NotifType, { icon: typeof Bell; bg: string; iconColor: string; border: string }> = {
  aid:    { icon: CheckCircle, bg: 'bg-[#e8f5ef]', iconColor: 'text-[#2D6A4F]', border: 'border-[#c5e8d8]' },
  alert:  { icon: AlertCircle, bg: 'bg-red-50',    iconColor: 'text-red-500',   border: 'border-red-100'   },
  info:   { icon: Info,        bg: 'bg-blue-50',   iconColor: 'text-blue-500',  border: 'border-blue-100'  },
  system: { icon: FileText,    bg: 'bg-gray-100',  iconColor: 'text-gray-500',  border: 'border-gray-200'  },
};

const TABS: { id: FilterTab; label: string }[] = [
  { id: 'all',    label: 'الكل'       },
  { id: 'unread', label: 'غير مقروء' },
  { id: 'urgent', label: 'عاجل'      },
  { id: 'system', label: 'النظام'    },
];

/* ─────────────────────────── Notification Card ─────────────── */
function NotifCard({
  notif,
  onRead,
  onDelete,
}: {
  notif: Notification;
  onRead: (id: number) => void;
  onDelete: (id: number) => void;
}) {
  const cfg = TYPE_CONFIG[notif.type];
  const Icon = cfg.icon;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: 30 }}
      transition={{ duration: 0.25 }}
      className={`relative flex gap-4 p-5 rounded-2xl border transition-all group
        ${notif.read
          ? 'bg-white border-gray-100'
          : 'bg-white border-[#2D6A4F]/20 shadow-sm'
        }`}
    >
      {/* Unread dot */}
      {!notif.read && (
        <span className="absolute top-4 left-4 w-2 h-2 rounded-full bg-[#FFB703]" />
      )}

      {/* Icon */}
      <div className={`w-11 h-11 rounded-xl ${cfg.bg} border ${cfg.border} flex items-center justify-center flex-shrink-0 mt-0.5`}>
        <Icon size={18} className={cfg.iconColor} />
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-4 mb-1">
          <h4 className={`text-sm leading-snug ${notif.read ? 'text-gray-700' : 'text-[#212529]'}`}>
            {notif.title}
          </h4>
          {notif.urgent && !notif.read && (
            <span className="flex-shrink-0 px-2 py-0.5 rounded-full bg-red-50 text-red-600 text-[10px] border border-red-100">
              عاجل
            </span>
          )}
        </div>
        <p className="text-gray-400 text-xs leading-relaxed mb-3 line-clamp-2">{notif.body}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-gray-300 text-xs">
            <Clock size={11} />
            {notif.time}
          </div>
          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            {!notif.read && (
              <button
                onClick={() => onRead(notif.id)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#e8f5ef] text-[#2D6A4F] text-xs hover:bg-[#c5e8d8] transition-colors"
              >
                <CheckCheck size={11} />
                تحديد كمقروء
              </button>
            )}
            <button
              onClick={() => onDelete(notif.id)}
              className="w-7 h-7 rounded-lg bg-red-50 text-red-400 hover:bg-red-100 hover:text-red-600 flex items-center justify-center transition-colors"
            >
              <Trash2 size={13} />
            </button>
          </div>
        </div>
      </div>

      <button className="flex-shrink-0 w-6 h-6 flex items-center justify-center text-gray-300 hover:text-[#2D6A4F] transition-colors mt-1">
        <ChevronLeft size={16} />
      </button>
    </motion.div>
  );
}

/* ─────────────────────────── Page ──────────────────────────── */
export function NotificationsPage() {
  const [notifs, setNotifs] = useState<Notification[]>(NOTIFS);
  const [activeTab, setActiveTab] = useState<FilterTab>('all');

  const unreadCount = notifs.filter(n => !n.read).length;

  const filtered = notifs.filter(n => {
    if (activeTab === 'unread') return !n.read;
    if (activeTab === 'urgent') return n.urgent;
    if (activeTab === 'system') return n.type === 'system';
    return true;
  });

  const markAllRead = () => setNotifs(prev => prev.map(n => ({ ...n, read: true })));
  const markRead    = (id: number) => setNotifs(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  const deleteNotif = (id: number) => setNotifs(prev => prev.filter(n => n.id !== id));

  return (
    <DashboardShell>
      {/* Page Title */}
      <motion.div
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        className="mb-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-[#212529] flex items-center gap-2">
              الإشعارات
              {unreadCount > 0 && (
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[#FFB703] text-[#212529] text-xs">
                  {unreadCount}
                </span>
              )}
            </h2>
            <p className="text-gray-400 text-sm mt-0.5">تتبع آخر التحديثات المتعلقة بطلباتك</p>
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-[#2D6A4F] text-[#2D6A4F] hover:bg-[#e8f5ef] transition-colors text-sm"
            >
              <CheckCheck size={16} />
              تحديد الكل كمقروء
            </button>
          )}
        </div>
      </motion.div>

      {/* Summary Cards */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6"
      >
        {[
          { label: 'إجمالي الإشعارات', value: notifs.length, bg: 'bg-white', text: 'text-[#212529]', sub: 'text-gray-400' },
          { label: 'غير مقروء',        value: unreadCount,   bg: 'bg-[#FFB703]', text: 'text-[#7a5400]', sub: 'text-[#a07320]' },
          { label: 'عاجلة',            value: notifs.filter(n => n.urgent).length, bg: 'bg-red-50', text: 'text-red-700', sub: 'text-red-400' },
          { label: 'من النظام',        value: notifs.filter(n => n.type === 'system').length, bg: 'bg-white', text: 'text-[#212529]', sub: 'text-gray-400' },
        ].map((card, i) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 + i * 0.05 }}
            className={`${card.bg} rounded-2xl p-4 border border-gray-100 shadow-sm`}
          >
            <p className={`text-2xl mb-0.5 ${card.text}`}>{card.value}</p>
            <p className={`text-xs ${card.sub}`}>{card.label}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Tabs + List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden"
      >
        {/* Tabs */}
        <div className="flex items-center gap-1 p-4 border-b border-gray-100 overflow-x-auto">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm transition-all duration-200
                ${activeTab === tab.id
                  ? 'bg-[#2D6A4F] text-white shadow-sm'
                  : 'text-gray-500 hover:bg-gray-100'
                }`}
            >
              {tab.label}
              {tab.id === 'unread' && unreadCount > 0 && (
                <span className="mr-2 px-1.5 py-0.5 rounded-full bg-[#FFB703] text-[#212529] text-[10px]">
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="p-4 space-y-3">
          <AnimatePresence mode="popLayout">
            {filtered.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-16 text-gray-300"
              >
                <Bell size={40} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm">لا توجد إشعارات في هذا القسم</p>
              </motion.div>
            ) : (
              filtered.map(notif => (
                <NotifCard
                  key={notif.id}
                  notif={notif}
                  onRead={markRead}
                  onDelete={deleteNotif}
                />
              ))
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-gray-100 text-xs text-gray-400 flex items-center justify-between">
          <span>عرض {filtered.length} من {notifs.length} إشعار</span>
          <button
            onClick={() => setNotifs(prev => prev.filter(n => !n.read))}
            className="hover:text-red-500 transition-colors flex items-center gap-1"
          >
            <Trash2 size={12} />
            حذف المقروءة
          </button>
        </div>
      </motion.div>
    </DashboardShell>
  );
}
