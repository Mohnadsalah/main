import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { HeartHandshake, ShieldCheck } from 'lucide-react';
import { getSupabase, isSupabaseConfigured } from '../supabase';
import { Navigation } from '../components/Navigation';

export function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setMessage('');
    const supabase = getSupabase();
    if (!supabase) { setMessage('الاتصال بقاعدة البيانات غير مُعد بعد. اتبع خطوات DATABASE-SETUP-AR.md أولاً.'); return; }
    setBusy(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        navigate('/request');
      } else {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password });
        if (error) throw error;
        if (data.session) navigate('/request');
        else setMessage('تم إنشاء الحساب. افتح بريدك الإلكتروني لتأكيده، ثم سجّل الدخول.');
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'تعذّر إكمال العملية. حاول مرة أخرى.');
    } finally { setBusy(false); }
  }

  return <div dir="rtl" className="min-h-screen bg-[#F8F9FA]"><Navigation />
    <main className="max-w-lg mx-auto px-4 pt-28 pb-16">
      <section className="bg-white rounded-3xl border border-gray-100 shadow-xl p-7 sm:p-9">
        <div className="w-14 h-14 rounded-2xl bg-[#e8f5ef] text-[#2D6A4F] grid place-items-center mb-5"><HeartHandshake size={28}/></div>
        <h1 className="text-2xl font-bold text-[#212529]">{mode === 'login' ? 'تسجيل الدخول إلى إسناد' : 'إنشاء حساب مستفيد'}</h1>
        <p className="text-sm text-gray-500 mt-2 leading-6">سجّل الدخول للوصول الآمن إلى طلباتك. لا تستخدم بيانات شخصية حقيقية حتى يكتمل إعداد المشروع واختباره.</p>
        {!isSupabaseConfigured && <div className="mt-5 rounded-xl bg-amber-50 border border-amber-200 p-3 text-sm text-amber-800">قاعدة البيانات غير متصلة بعد. جهّز متغيرات البيئة وفق الدليل العربي.</div>}
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <label className="block text-sm text-gray-700">البريد الإلكتروني<input required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 outline-none focus:border-[#2D6A4F]" placeholder="name@example.com"/></label>
          <label className="block text-sm text-gray-700">كلمة المرور<input required minLength={8} type="password" autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)} className="mt-1.5 w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 outline-none focus:border-[#2D6A4F]" placeholder="8 أحرف على الأقل"/></label>
          {message && <p role="status" className="rounded-xl bg-sky-50 border border-sky-100 p-3 text-sm text-sky-800">{message}</p>}
          <button disabled={busy || !isSupabaseConfigured} className="w-full rounded-xl bg-[#2D6A4F] text-white font-bold py-3.5 disabled:opacity-50">{busy?'جارٍ المعالجة…':mode==='login'?'تسجيل الدخول':'إنشاء الحساب'}</button>
        </form>
        <button onClick={()=>{setMode(mode==='login'?'signup':'login');setMessage('');}} className="w-full mt-4 text-sm text-[#2D6A4F]">{mode==='login'?'ليس لديك حساب؟ أنشئ حسابًا':'لديك حساب؟ سجّل الدخول'}</button>
        <div className="mt-6 flex items-start gap-2 text-xs leading-5 text-gray-400"><ShieldCheck size={16} className="shrink-0 mt-0.5"/> لا يتم تخزين كلمة المرور في قاعدة بيانات إسناد؛ يتولى Supabase Auth إدارة المصادقة.</div>
        <Link to="/" className="block text-center mt-5 text-sm text-gray-500">العودة إلى الرئيسية</Link>
      </section>
    </main>
  </div>;
}
