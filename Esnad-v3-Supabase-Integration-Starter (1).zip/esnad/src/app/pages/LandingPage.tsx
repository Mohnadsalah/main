import { Navigation } from '../components/Navigation';
import { HeroSection } from '../components/HeroSection';
import { StatisticsSection } from '../components/StatisticsSection';

export function LandingPage() {
  return (
    <div className="min-h-screen bg-[#F8F9FA] overflow-x-hidden" dir="rtl">
      <Navigation />
      <main>
        <HeroSection />
        <StatisticsSection />
      </main>
      <footer className="bg-[#102f23] text-white/70 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm">
          <span>© {new Date().getFullYear()} إسناد — نصنع أثراً يستمر.</span>
          <span className="text-white/45">منصة إنسانية للثقة والعطاء والشفافية</span>
        </div>
      </footer>
    </div>
  );
}
