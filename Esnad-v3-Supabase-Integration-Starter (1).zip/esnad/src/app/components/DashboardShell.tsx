import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import { motion } from 'motion/react';
import { LayoutDashboard, FileText, Bell, User, HelpCircle, Menu, X, ShieldCheck, ChevronLeft } from 'lucide-react';

const NAV_ITEMS = [
  { icon: LayoutDashboard, label: 'لوحة التحكم', to: '/dashboard' },
  { icon: FileText, label: 'طلباتي', to: '/requests' },
  { icon: Bell, label: 'الإشعارات', to: '/notifications', badge: 5 },
  { icon: User, label: 'ملفي الشخصي', to: '/profile' },
  { icon: HelpCircle, label: 'الدعم والمساعدة', to: '/contact' },
];

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const { pathname } = useLocation();

  return (
    <div dir="rtl" className="flex h-screen bg-[#F8F9FA] text-[#212529] overflow-hidden">
      {open && <button aria-label="إغلاق القائمة" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-[#102a20]/45 lg:hidden" />}
      <aside className={`fixed lg:relative z-50 inset-y-0 right-0 lg:right-auto w-[280px] ${collapsed ? 'lg:w-[82px]' : 'lg:w-[280px]'} bg-[#123d2d] text-white transition-all duration-300 ${open ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'} flex flex-col shadow-2xl lg:shadow-none`}>
        <div className="h-20 px-4 border-b border-white/10 flex items-center gap-3">
          <Link to="/" className="w-11 h-11 rounded-2xl bg-[#FFB703] text-[#212529] grid place-items-center font-black text-xl shadow-lg">إ</Link>
          {!collapsed && <div className="flex-1"><div className="font-bold text-lg">إسناد</div><div className="text-[11px] text-white/55">منصة الأثر الإنساني</div></div>}
          <button onClick={() => setOpen(false)} className="lg:hidden p-2 rounded-xl hover:bg-white/10"><X size={19}/></button>
        </div>

        {!collapsed && <div className="mx-4 mt-5 p-3 rounded-2xl bg-white/[.07] border border-white/10"><div className="flex items-center gap-2 text-xs text-white/60"><span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"/> النظام يعمل بكفاءة</div><div className="mt-2 text-sm font-medium">السعودية · وضع تجريبي</div></div>}

        <nav className="flex-1 px-3 py-5 space-y-1.5 overflow-y-auto">
          {NAV_ITEMS.map(({ icon: Icon, label, to, badge }) => {
            const active = pathname === to;
            return <Link key={to} to={to} onClick={() => setOpen(false)} className={`relative flex items-center gap-3 px-3 py-3 rounded-2xl transition-all ${active ? 'bg-white text-[#123d2d] shadow-lg' : 'text-white/70 hover:text-white hover:bg-white/[.08]'} ${collapsed ? 'lg:justify-center' : ''}`}>
              <div className="relative"><Icon size={19}/>{badge && <span className={`absolute -top-2 -left-2 w-4 h-4 rounded-full text-[9px] grid place-items-center ${active ? 'bg-[#FFB703] text-[#212529]' : 'bg-[#FFB703] text-[#212529]'}`}>{badge}</span>}</div>
              {!collapsed && <span className="text-sm font-medium">{label}</span>}
              {active && !collapsed && <ChevronLeft size={15} className="mr-auto opacity-50"/>}
            </Link>;
          })}
        </nav>

        <div className="p-3 border-t border-white/10">
          <div className={`flex items-center gap-3 p-2 rounded-2xl bg-white/[.06] ${collapsed ? 'lg:justify-center' : ''}`}>
            <div className="w-10 h-10 rounded-full bg-[#A9D6E5] text-[#123d2d] grid place-items-center font-bold">أ</div>
            {!collapsed && <div className="min-w-0"><div className="text-sm font-bold truncate">موضي إبراهيم</div><div className="text-[11px] text-white/50">مستفيد · حساب موثق</div></div>}
          </div>
          <button onClick={() => setCollapsed(v => !v)} className="hidden lg:flex w-full mt-2 items-center justify-center gap-2 py-2 text-xs text-white/45 hover:text-white transition-colors"><Menu size={14}/> {collapsed ? 'توسيع' : 'تصغير القائمة'}</button>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        <header className="h-[72px] bg-white/90 backdrop-blur border-b border-slate-200/70 flex items-center justify-between px-4 md:px-7 flex-shrink-0 sticky top-0 z-30">
          <div className="flex items-center gap-3"><button onClick={() => setOpen(true)} className="lg:hidden w-10 h-10 rounded-xl bg-slate-50 grid place-items-center"><Menu size={20}/></button><div><div className="text-xs text-slate-400">مساء الخير 👋</div><div className="font-bold text-sm md:text-base">جاهز تتابع أثر طلباتك؟</div></div></div>
          <div className="flex items-center gap-2"><div className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl bg-[#e8f5ef] text-[#2D6A4F] text-xs font-medium"><ShieldCheck size={15}/> بياناتك محمية</div><Link to="/notifications" className="relative w-10 h-10 rounded-xl bg-slate-50 grid place-items-center hover:bg-slate-100"><Bell size={18}/><span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#FFB703]"/></Link><Link to="/" className="hidden sm:flex px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold hover:border-[#2D6A4F] hover:text-[#2D6A4F]">الرئيسية</Link></div>
        </header>
        <main className="flex-1 overflow-y-auto"><div className="max-w-[1500px] mx-auto p-4 md:p-7 lg:p-8">{children}</div></main>
      </div>
    </div>
  );
}
