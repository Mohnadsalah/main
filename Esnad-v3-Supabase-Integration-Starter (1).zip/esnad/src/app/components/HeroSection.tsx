import { motion } from 'motion/react';
import { ArrowLeft, ShieldCheck, Sparkles } from 'lucide-react';
import { Link } from 'react-router';

export function HeroSection() {
  return (
    <section className="relative min-h-[720px] h-[92vh] flex items-center overflow-hidden bg-[#123b2b]">
      <div className="absolute inset-0">
        <img src="https://images.unsplash.com/photo-1630510590497-e69fac21bfbd?auto=format&fit=crop&w=2200&q=85" alt="أيد تتعاون للمساعدة" className="w-full h-full object-cover scale-[1.03]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_45%,rgba(45,106,79,.28),transparent_42%),linear-gradient(100deg,rgba(7,30,22,.9),rgba(20,65,48,.62),rgba(7,25,19,.82))]" />
      </div>

      <div className="absolute -top-40 -right-32 w-[520px] h-[520px] rounded-full bg-[#A9D6E5]/10 blur-3xl" />
      <div className="absolute -bottom-48 -left-24 w-[500px] h-[500px] rounded-full bg-[#FFB703]/10 blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-20">
        <div className="max-w-3xl text-right">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .6 }} className="inline-flex items-center gap-2 px-3.5 py-2 rounded-full border border-white/15 bg-white/10 backdrop-blur-md text-white/90 text-sm mb-7">
            <Sparkles size={15} className="text-[#FFB703]" />
            العطاء يبدأ بالثقة… والأثر يصنع الفرق
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .08 }} className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-[1.18] tracking-tight mb-7">
            نساند الإنسان،<br /><span className="text-[#A9D6E5]">ونصنع أثراً يستمر.</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .16 }} className="text-lg sm:text-xl text-white/80 leading-9 max-w-2xl mb-9">
            منصة إنسانية تربط المحتاج بالمساعدة المناسبة، وتمنح المتبرع رؤية واضحة لرحلة عطائه من أول مساهمة حتى وصول الأثر.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .7, delay: .24 }} className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
            <Link to="/request" className="group inline-flex items-center justify-center gap-3 px-7 py-4 rounded-2xl bg-[#FFB703] text-[#212529] font-bold shadow-xl shadow-black/15 hover:-translate-y-1 transition-all">
              أحتاج إلى مساعدة
              <ArrowLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
            </Link>
            <Link to="/impact" className="inline-flex items-center justify-center gap-3 px-7 py-4 rounded-2xl bg-white/10 border border-white/20 backdrop-blur-md text-white font-semibold hover:bg-white/15 transition-all">
              اكتشف أثر إسناد
            </Link>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .55, duration: .8 }} className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-3 text-white/70 text-sm">
            <span className="inline-flex items-center gap-2"><ShieldCheck size={17} className="text-[#A9D6E5]" /> شفافية في كل خطوة</span>
            <span className="w-1 h-1 rounded-full bg-white/30 hidden sm:block" />
            <span>بياناتك محفوظة وآمنة</span>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/45 text-[10px] tracking-[.25em]">
        <span>اكتشف</span><span className="w-px h-9 bg-white/30 animate-pulse" />
      </div>
    </section>
  );
}
