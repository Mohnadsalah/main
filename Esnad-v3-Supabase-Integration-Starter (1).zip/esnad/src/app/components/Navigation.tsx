import { useEffect, useState } from 'react';
import { Menu, X, ArrowLeft, HeartHandshake } from 'lucide-react';
import { Link, useLocation } from 'react-router';

const NAV_LINKS = [
  { to: '/about', label: 'من نحن' },
  { to: '/programs', label: 'البرامج' },
  { to: '/impact', label: 'الأثر' },
  { to: '/contact', label: 'تواصل معنا' },
];

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? 'bg-white/90 backdrop-blur-xl shadow-[0_8px_30px_rgba(45,106,79,0.08)] border-b border-[#2D6A4F]/10' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[76px]">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className={`md:hidden p-2.5 rounded-xl transition-colors ${scrolled ? 'text-[#212529] hover:bg-[#2D6A4F]/5' : 'text-white hover:bg-white/10'}`}
            aria-label="فتح القائمة"
          >
            {mobileMenuOpen ? <X size={23} /> : <Menu size={23} />}
          </button>

          <div className="hidden md:flex items-center gap-7 flex-1">
            {NAV_LINKS.map(({ to, label }) => (
              <Link
                key={to}
                to={to}
                className={`relative py-2 text-sm font-semibold transition-colors ${pathname === to ? (scrolled ? 'text-[#2D6A4F]' : 'text-white') : (scrolled ? 'text-[#212529]/75 hover:text-[#2D6A4F]' : 'text-white/85 hover:text-white')}`}
              >
                {label}
                {pathname === to && <span className={`absolute -bottom-1 right-0 left-0 h-0.5 rounded-full ${scrolled ? 'bg-[#FFB703]' : 'bg-[#FFB703]'}`} />}
              </Link>
            ))}
          </div>

          <Link to="/" className="group flex items-center gap-2.5 shrink-0" aria-label="إسناد - الرئيسية">
            <span className={`text-3xl font-bold tracking-tight transition-colors ${scrolled ? 'text-[#2D6A4F]' : 'text-white'}`}>إسناد</span>
            <span className="w-9 h-9 rounded-xl bg-[#FFB703] text-[#212529] grid place-items-center shadow-lg shadow-black/10 group-hover:rotate-6 group-hover:scale-105 transition-transform">
              <HeartHandshake size={19} />
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-2 flex-1 justify-end">
            <Link to="/donate" className={`px-4 py-2.5 rounded-xl border font-semibold text-sm transition-all ${scrolled ? 'border-[#FFB703]/70 text-[#7a5400] hover:bg-[#FFB703]' : 'border-white/30 text-white hover:bg-white/10'}`}>
              تبرع الآن
            </Link>
            <Link to="/request" className="px-4 py-2.5 rounded-xl bg-[#FFB703] text-[#212529] font-bold text-sm shadow-lg shadow-[#FFB703]/20 hover:-translate-y-0.5 hover:shadow-xl transition-all">
              اطلب مساعدة
            </Link>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden pb-4">
            <div className="rounded-2xl bg-white/95 backdrop-blur-xl p-3 shadow-2xl border border-gray-100">
              {NAV_LINKS.map(({ to, label }) => (
                <Link key={to} to={to} onClick={() => setMobileMenuOpen(false)} className={`block px-4 py-3 rounded-xl text-sm font-semibold ${pathname === to ? 'bg-[#e8f5ef] text-[#2D6A4F]' : 'text-[#212529] hover:bg-gray-50'}`}>
                  {label}
                </Link>
              ))}
              <div className="grid grid-cols-2 gap-2 pt-3 mt-2 border-t border-gray-100">
                <Link to="/donate" onClick={() => setMobileMenuOpen(false)} className="py-3 rounded-xl border-2 border-[#FFB703] text-center text-sm font-bold text-[#7a5400]">تبرع الآن</Link>
                <Link to="/request" onClick={() => setMobileMenuOpen(false)} className="py-3 rounded-xl bg-[#2D6A4F] text-center text-sm font-bold text-white">اطلب مساعدة</Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
