import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, HeartHandshake, Users, CircleDollarSign } from 'lucide-react';
import { Link } from 'react-router';

function Counter({ end, duration = 1.8, suffix = '' }: { end: number; duration?: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    let raf = 0;
    const startTime = performance.now();
    const tick = (now: number) => {
      const progress = Math.min((now - startTime) / (duration * 1000), 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(end * eased));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [end, duration]);
  return <>{count.toLocaleString('ar-SA')}{suffix}</>;
}

const stats = [
  { value: 50_000_000, suffix: '+', label: 'ريال من المساعدات', icon: CircleDollarSign },
  { value: 12_500, suffix: '+', label: 'متبرعاً نشطاً', icon: Users },
  { value: 8_750, suffix: '+', label: 'حالة مستفيدة', icon: HeartHandshake },
];

export function StatisticsSection() {
  return (
    <>
      <section className="relative py-24 bg-[#F8F9FA] overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-l from-transparent via-[#2D6A4F]/20 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 15 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
            <span className="text-[#2D6A4F] font-bold text-sm">أثر يمكن قياسه</span>
            <h2 className="text-3xl md:text-5xl font-bold text-[#212529] mt-3">أرقام تحكي قصة العطاء</h2>
            <p className="text-gray-500 mt-4 max-w-2xl mx-auto leading-8">كل رقم هنا يمثل إنساناً، أسرة، أو فرصة جديدة بدأت بقرار بسيط: أن نساند.</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {stats.map((stat, i) => (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * .1 }} className="group relative bg-white rounded-3xl p-7 border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all overflow-hidden">
                <div className="absolute -top-12 -left-12 w-32 h-32 rounded-full bg-[#A9D6E5]/25 blur-2xl group-hover:bg-[#FFB703]/20 transition-colors" />
                <div className="relative flex items-start justify-between">
                  <div className="w-12 h-12 rounded-2xl bg-[#e8f5ef] text-[#2D6A4F] grid place-items-center"><stat.icon size={22} /></div>
                  <span className="text-xs text-[#2D6A4F] bg-[#e8f5ef] px-3 py-1.5 rounded-full">يتجدد باستمرار</span>
                </div>
                <div className="relative text-4xl md:text-5xl font-bold text-[#212529] mt-7"><Counter end={stat.value} suffix={stat.suffix} /></div>
                <p className="relative text-gray-500 mt-2">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-[1.1fr_.9fr] gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: 25 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <span className="text-[#2D6A4F] font-bold text-sm">كيف تعمل إسناد؟</span>
              <h2 className="text-3xl md:text-5xl font-bold text-[#212529] mt-3 leading-tight">من الاحتياج إلى الأثر<br /><span className="text-[#2D6A4F]">بخطوات واضحة.</span></h2>
              <div className="mt-8 space-y-5">
                {['تقديم الطلب أو اختيار فرصة للتبرع', 'مراجعة البيانات وتحديد نوع الدعم المناسب', 'تنفيذ المساعدة ومتابعة الحالة حتى الإغلاق'].map((item, i) => (
                  <div key={item} className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#2D6A4F] text-white grid place-items-center font-bold shrink-0">{i + 1}</div>
                    <p className="text-gray-600 leading-7">{item}</p>
                  </div>
                ))}
              </div>
              <Link to="/about" className="inline-flex items-center gap-2 mt-8 text-[#2D6A4F] font-bold hover:gap-3 transition-all">تعرف علينا أكثر <ArrowLeft size={17} /></Link>
            </motion.div>
            <motion.div initial={{ opacity: 0, scale: .96 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} className="relative rounded-[2rem] p-8 bg-[#2D6A4F] overflow-hidden shadow-2xl">
              <div className="absolute -top-24 -left-24 w-64 h-64 rounded-full border-[40px] border-white/5" />
              <div className="absolute -bottom-24 -right-20 w-72 h-72 rounded-full border-[55px] border-[#FFB703]/10" />
              <div className="relative">
                <div className="flex items-center justify-between text-white/70 text-sm"><span>شفافية الأثر</span><span className="text-[#FFB703] font-bold">98%</span></div>
                <div className="h-3 bg-white/10 rounded-full mt-3 overflow-hidden"><motion.div initial={{ width: 0 }} whileInView={{ width: '98%' }} viewport={{ once: true }} transition={{ duration: 1.2 }} className="h-full bg-[#FFB703] rounded-full" /></div>
                <div className="grid grid-cols-2 gap-4 mt-10">
                  <div className="rounded-2xl bg-white/10 p-5"><p className="text-white/60 text-xs">طلبات قيد المتابعة</p><p className="text-3xl font-bold text-white mt-2">٣,٢٤٠</p></div>
                  <div className="rounded-2xl bg-white/10 p-5"><p className="text-white/60 text-xs">مساعدة مكتملة</p><p className="text-3xl font-bold text-white mt-2">٨,٧٥٠</p></div>
                </div>
                <div className="mt-5 p-4 rounded-2xl bg-white text-[#212529] text-sm leading-7">هدفنا ليس فقط إيصال المساعدة، بل أن تعرف كيف وصلت ولماذا كان لها أثر.</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
}
