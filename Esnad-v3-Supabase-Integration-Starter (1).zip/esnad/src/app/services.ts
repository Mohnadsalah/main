/** Local prototype storage for Esnad requests.
 * This is intentionally a browser-only demo adapter, not a production database.
 * Replace it with an authenticated API before storing real beneficiary data.
 */
export type RequestStatus = 'approved' | 'pending' | 'completed' | 'rejected';
export type StoredRequest = {
  id: string;
  type: string;
  date: string;
  createdAt: string;
  status: RequestStatus;
  priority: 'عالية' | 'متوسطة' | 'منخفضة';
  region: string;
  notes: string;
  personal: { fullName: string; phone: string; address: string; maritalStatus: string; notes: string };
  eligibility: { familySize: string; hasIncome: string; monthlyIncome: string; urgent: boolean };
  programs: string[];
  documents: { nationalId: boolean; familyDoc: boolean; addressProof: boolean; medicalDoc: boolean };
};

const STORAGE_KEY = 'esnad.demo.requests.v1';

export type RequestSubmission = Omit<StoredRequest, 'id' | 'date' | 'createdAt' | 'status' | 'priority' | 'notes'>;


/** Submit through Supabase when configured; localStorage is retained only for an explicitly unconfigured demo. */
export async function submitRequest(input: RequestSubmission): Promise<StoredRequest> {
  const { getSupabase, isSupabaseConfigured } = await import('./supabase');
  const supabase = getSupabase();
  if (!supabase) {
    if (isSupabaseConfigured) throw new Error('تعذّر تهيئة اتصال قاعدة البيانات.');
    return saveRequest(input);
  }
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) throw new Error('يلزم تسجيل الدخول قبل تقديم الطلب.');

  const { error: profileError } = await supabase.from('beneficiary_profiles').upsert({
    id: user.id,
    full_name: input.personal.fullName,
    phone: input.personal.phone,
    region: input.region,
    address: input.personal.address,
    marital_status: input.personal.maritalStatus,
    family_size: Number(input.eligibility.familySize),
    has_income: input.eligibility.hasIncome === 'نعم',
    monthly_income: input.eligibility.monthlyIncome ? Number(input.eligibility.monthlyIncome) : null,
  }, { onConflict: 'id' });
  if (profileError) throw new Error(`تعذّر حفظ الملف الشخصي: ${profileError.message}`);

  const { data: row, error: requestError } = await supabase.from('aid_requests').insert({
    beneficiary_id: user.id,
    programs: input.programs,
    urgent: input.eligibility.urgent,
    beneficiary_notes: input.personal.notes || null,
  }).select('id, reference_code, status, submitted_at').single();
  if (requestError) throw new Error(`تعذّر حفظ الطلب: ${requestError.message}`);

  const date = new Intl.DateTimeFormat('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(row.submitted_at));
  return {
    ...input,
    id: row.reference_code || row.id,
    createdAt: row.submitted_at,
    date,
    status: row.status === 'approved' ? 'approved' : row.status === 'completed' ? 'completed' : row.status === 'rejected' ? 'rejected' : 'pending',
    priority: input.eligibility.urgent ? 'عالية' : 'متوسطة',
    notes: 'تم استلام الطلب، وهو قيد المراجعة',
  };
}

export function getStoredRequests(): StoredRequest[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StoredRequest[]) : [];
  } catch {
    return [];
  }
}

export function saveRequest(input: Omit<StoredRequest, 'id' | 'date' | 'createdAt' | 'status' | 'priority' | 'notes'>): StoredRequest {
  const now = new Date();
  const id = `REQ-${now.getFullYear()}-${now.getTime().toString().slice(-6)}`;
  const request: StoredRequest = {
    ...input,
    id,
    createdAt: now.toISOString(),
    date: new Intl.DateTimeFormat('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' }).format(now),
    status: 'pending',
    priority: input.eligibility.urgent ? 'عالية' : 'متوسطة',
    notes: 'تم استلام الطلب، وهو قيد المراجعة',
  };
  const requests = getStoredRequests();
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify([request, ...requests]));
  window.dispatchEvent(new CustomEvent('esnad:requests-updated'));
  return request;
}

/** Fetch only the signed-in beneficiary's requests; database RLS remains the source of authorization. */
export async function getMyRequests(): Promise<StoredRequest[]> {
  const { getSupabase, isSupabaseConfigured } = await import('./supabase');
  const supabase = getSupabase();
  if (!supabase) return getStoredRequests();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];
  const { data, error } = await supabase.from('aid_requests')
    .select('id, reference_code, programs, urgent, status, beneficiary_notes, review_notes, submitted_at, beneficiary_profiles(region, full_name, phone, address, marital_status, family_size, has_income, monthly_income)')
    .eq('beneficiary_id', user.id)
    .order('submitted_at', { ascending: false });
  if (error) throw new Error(`تعذّر جلب الطلبات: ${error.message}`);
  return (data ?? []).map((row: any) => {
    const profile = Array.isArray(row.beneficiary_profiles) ? row.beneficiary_profiles[0] : row.beneficiary_profiles;
    const createdAt = row.submitted_at as string;
    const status: RequestStatus = row.status === 'approved' ? 'approved' : row.status === 'completed' ? 'completed' : row.status === 'rejected' ? 'rejected' : 'pending';
    return {
      id: row.reference_code || row.id,
      type: (row.programs as string[]).map((id: string) => ({ food: 'مساعدة غذائية', medical: 'رعاية طبية', education: 'دعم تعليمي', housing: 'مساعدة إيواء', mental: 'دعم نفسي', financial: 'مساعدة مالية', clothing: 'كسوة موسمية', equipment: 'معدات منزلية' } as Record<string, string>)[id] ?? id).join('، '),
      date: new Intl.DateTimeFormat('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(createdAt)),
      createdAt, status, priority: row.urgent ? 'عالية' : 'متوسطة', region: profile?.region ?? '',
      notes: row.review_notes || row.beneficiary_notes || 'تم استلام الطلب، وهو قيد المراجعة',
      personal: { fullName: profile?.full_name ?? '', phone: profile?.phone ?? '', address: profile?.address ?? '', maritalStatus: profile?.marital_status ?? '', notes: row.beneficiary_notes ?? '' },
      eligibility: { familySize: String(profile?.family_size ?? ''), hasIncome: profile?.has_income ? 'نعم' : 'لا', monthlyIncome: profile?.monthly_income == null ? '' : String(profile.monthly_income), urgent: Boolean(row.urgent) },
      programs: row.programs as string[], documents: { nationalId: false, familyDoc: false, addressProof: false, medicalDoc: false },
    } as StoredRequest;
  });
}

