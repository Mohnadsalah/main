import { createBrowserRouter } from 'react-router';
import { LandingPage }          from './pages/LandingPage';
import { BeneficiaryDashboard } from './pages/BeneficiaryDashboard';
import { AboutPage }            from './pages/AboutPage';
import { ProgramsPage }         from './pages/ProgramsPage';
import { ImpactPage }           from './pages/ImpactPage';
import { ContactPage }          from './pages/ContactPage';
import { NotificationsPage }    from './pages/NotificationsPage';
import { ProfilePage }          from './pages/ProfilePage';
import { RequestPage }          from './pages/RequestPage';
import { DonatePage }           from './pages/DonatePage';
import { RequestsPage }         from './pages/RequestsPage';
import { AuthPage }             from './pages/AuthPage';

export const router = createBrowserRouter([
  { path: '/',              Component: LandingPage          },
  { path: '/about',         Component: AboutPage            },
  { path: '/programs',      Component: ProgramsPage         },
  { path: '/impact',        Component: ImpactPage           },
  { path: '/contact',       Component: ContactPage          },
  { path: '/request',       Component: RequestPage          },
  { path: '/login',         Component: AuthPage              },
  { path: '/donate',        Component: DonatePage           },
  { path: '/dashboard',     Component: BeneficiaryDashboard },
  { path: '/requests',      Component: RequestsPage         },
  { path: '/notifications', Component: NotificationsPage    },
  { path: '/profile',       Component: ProfilePage          },
]);
