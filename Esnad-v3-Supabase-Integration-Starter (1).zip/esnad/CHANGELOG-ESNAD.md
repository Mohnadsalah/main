# Esnad — UI Upgrade

## What changed
- Redesigned the landing page as a modern humanitarian product experience.
- Added a scroll-aware glass navigation bar and improved mobile navigation.
- Rebuilt the hero section with stronger hierarchy, CTAs, trust messaging, motion, and visual depth.
- Rebuilt the impact/statistics section with animated counters and richer cards.
- Added a three-step "from need to impact" story section.
- Added a stronger visual impact/metrics panel.
- Added a polished responsive footer.
- Added global focus-visible states, smooth scrolling, selection styling, and mobile tap improvements.

## Notes
The existing routes and application structure were preserved. This upgrade focuses on the first product impression and establishes a stronger visual system that can be extended to the dashboard and full-stack layers.
